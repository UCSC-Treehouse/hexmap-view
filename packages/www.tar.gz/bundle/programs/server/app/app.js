var require = meteorInstall({"server":{"bookmark.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/bookmark.js                                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let CryptoJS;
module.link("crypto-js", {
  default(v) {
    CryptoJS = v;
  }

}, 0);
var Bookmarks = new Mongo.Collection('bookmarks');

function humanToday() {
  var date = new Date(),
      intMonth = parseInt(date.getMonth()) + 1,
      strMonth = intMonth < 10 ? '0' + intMonth.toString() : intMonth.toString();
  return date.getFullYear() + '-' + strMonth + '-' + date.getDate();
}

function createId(jsonState) {
  // Generate a bookmark ID and URL.
  var id = CryptoJS.SHA256(jsonState).toString();
  return {
    id: id,
    url: URL_BASE + '/?bookmark=' + id
  };
}

exports.create = function (jsonState, username) {
  // Create or update a bookmark.
  var key = createId(jsonState),
      dbUsername = username,
      bookmark = Bookmarks.findOne(key.id.toString()); // If this bookmark already exists, update the user list.

  if (bookmark) {
    // Convert the db username and the given username to a single array
    // of unique elements.
    dbUsername = _.uniq([].concat(bookmark.username, username).filter(Boolean));
  } // Insert/update the state into the bookmark collection.


  Bookmarks.upsert({
    _id: key.id
  }, {
    $set: {
      jsonState: jsonState,
      username: dbUsername,
      lastAccess: humanToday()
    }
  });
  return {
    bookmark: key.url
  };
};

Meteor.methods({
  findBookmark: function (id) {
    try {
      var bookmark = Bookmarks.findOne(id.toString()),
          user = Meteor.user();

      if (!bookmark) {
        return 'Bookmark not found';
      } // TODO update the lastAccess date


      Bookmarks.update(id, {
        $set: {
          username: user ? user.username : undefined,
          lastAccess: humanToday()
        }
      });
      return JSON.parse(bookmark.jsonState);
    } catch (error) {
      console.log('findBookmark() failed with:', error.toString());
      console.trace();
      throw new Meteor.Error('Could not find bookmark', error.toString());
    }
  },
  createBookmark: function (jsonState) {
    // Save state in a bookmark, returning the URL.
    try {
      var user = Meteor.user(),
          result = exports.create(jsonState, user ? user.username : undefined);
      return result.bookmark;
    } catch (e) {
      console.log('saveBookmark() failed with:', e.toString());
      console.trace();
      throw new Meteor.Error('Could not create bookmark', e.toString());
    }
  }
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"http.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/http.js                                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let bookmark;
module.link("./bookmark", {
  default(v) {
    bookmark = v;
  }

}, 0);

function respond(statusCode, res, data_in) {
  // This responds to an http request before converting data to json.
  var data = JSON.stringify(data_in);
  res.setHeader('Content-Type', 'application/json');
  res.writeHead(statusCode);
  res.end(data + '\n');
}

function passPostChecks(req, res) {
  // Do some basic checks on the request headers,
  // returning false if not passing.
  // Only POST methods are understood
  if (req.method !== 'POST') {
    respond(405, res, 'Only the POST method is understood here');
  } // Only json content type is understood


  if (req.headers['content-type'] !== 'application/json') {
    respond(400, res, 'Only content-type of application/json is understood here');
  }
}

function parseJson(jsonData, res) {
  // Parse the json data.
  let data = null;

  try {
    data = JSON.parse(jsonData);
  } catch (e) {
    var msg = 'server error decoding JSON: ' + e;
    respond(500, res, {
      error: msg
    });
    return;
  }

  return data;
}

function updateBookmarkDatabase(jsonState, email, res) {
  return Promise.asyncApply(() => {
    try {
      let result = Promise.await(bookmark.create(jsonState, email));
      respond(200, res, result);
    } catch (error) {
      respond(500, res, {
        error: error
      });
    }
  });
}

function createBookmark(jsonData, req, res) {
  var data = parseJson(jsonData, res),
      jsonState = jsonData,
      email = null; // Extract the email if there is one.

  if (data.hasOwnProperty('email')) {
    email = data.email;
    delete data.email;
    jsonState = JSON.stringify(data);
  }

  updateBookmarkDatabase(jsonState, email, res);
}

function updateColor(jsonData, req, res) {
  return Promise.asyncApply(() => {
    let data = parseJson(jsonData, res);

    try {
      let user = Promise.await(Accounts.findUserByUsername(data.userEmail));
      data.userRole = Roles.getRolesForUser(user._id); // Request edit of the data server.

      let url = HUB_URL + '/updateColor';
      HTTP.call('POST', url, {
        data: data
      }, (error, result) => {
        if (error) {
          respond(500, res, result.data);
        } else {
          respond(200, res, result.data);
        }
      });
    } catch (error) {
      respond(500, res, {
        error: error
      });
    }
  });
}

function receivePost(operation, req, res) {
  // Receive a query for an operation and process it
  passPostChecks(req, res);
  var jsonData = '';
  req.setEncoding('utf8'); // Continue to receive chunks of this request

  req.on('data', function (chunk) {
    jsonData += chunk;
  }); // Process the data in this request

  req.on('end', function () {
    if (operation === 'createBookmark') {
      createBookmark(jsonData, req, res);
    } else if (operation === 'updateColor') {
      updateColor(jsonData, req, res);
    } else {
      respond(500, res, {
        error: 'no handler for this operation: ' + operation
      });
    }
  });
}

function editMapGet(operation, req, res) {
  // Edit a map on the data server.
  // Find the username.
  let urlParts = req.url.split('/');
  let username = urlParts[urlParts.indexOf('email') + 1]; // Get the user's roles.

  let user = Accounts.findUserByUsername(username);
  let roles = Roles.getRolesForUser(user._id);
  let url = HUB_URL + '/' + operation + req.url;

  if (roles.length > 0) {
    url += '/role/' + roles.join('+');
  } // Request edit of the data server.


  HTTP.call('GET', url, (error, result) => {
    if (error) {
      respond(500, res, error);
    } else {
      respond(200, res, result.data);
    }
  });
}

WebApp.connectHandlers.use('/test', function (req, res) {
  respond(200, res, 'just testing');
});
WebApp.connectHandlers.use('/query/createBookmark', function (req, res) {
  receivePost('createBookmark', req, res);
}); // /deleteMap/mapId/unitTest/noNeighbors/email/swat@soe.ucsc.edu

WebApp.connectHandlers.use('/deleteMap', function (req, res) {
  editMapGet('deleteMap', req, res);
});
WebApp.connectHandlers.use('/updateColor', function (req, res) {
  receivePost('updateColor', req, res);
});
HUB_URL = Meteor.settings.public.HUB_URL;
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"secure.js":function(require){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/secure.js                                                                                                //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
// secure.js
// This file contains all the meteor server code related to security:
// logins, associating users with roles, authorization...
function userActions() {
  //createRole('CIRM');
  //removeRoles(['Pancan12']);
  //removeUsersFromRoles(['jstuart@ucsc.edu'], ['dev', 'Pancan12']);
  //showUsernames();
  addUsersToRoles(['kchambe2@ucsc.edu'], ['CKCC']); //removeUser('swat@ucsc.edu');

  /*
  var users = [
      {email: 'kchambe2@ucsc.edu', roles: ['CKCC']},
  ];
  createUsers(users);
  */
}

function sendMail(users, subject, msg, callback) {
  // Send mail to user(s) with the given subject and message.
  // This can take one username or an array of usernames.
  var command = 'echo "' + msg + '" | ' + 'mail -s "' + subject + '" -S from="' + ADMIN_EMAIL + '" ' + users.toString();

  if (DEV) {
    console.log('sendMail():', command);
    return;
  }
  /* eslint-disable no-unused-vars */


  exec(command, function (error, stdout, stderr) {
    if (error) {
      var errMsg = 'Error on sendMail(): ' + error;
      console.log(errMsg);

      if (callback) {
        callback(errMsg);
      }
    } else {
      if (callback) {
        callback();
      }
    }
  });
}

function usernamesToUsers(usernamesIn) {
  var usernames = usernamesIn;

  if (typeof usernames === 'string') {
    usernames = [usernamesIn];
  }

  var array = _.map(usernames, function (username) {
    return Accounts.findUserByUsername(username);
  });

  if (typeof usernamesIn === 'string') {
    return array[0];
  }

  return array;
}

function sendEnrollmentEmail(username) {
  var user = usernamesToUsers(username);
  var token = Random.secret();
  var date = new Date();
  var tokenRecord = {
    token: token,
    email: user.username,
    when: date
  };
  Meteor.users.update(user._id, {
    $set: {
      "services.password.reset": tokenRecord
    }
  }); // Before emailing, update user object with new token

  Meteor._ensure(user, 'services', 'password').reset = tokenRecord;
  var enrollAccountUrl = Accounts.urls.enrollAccount(token);
  /*
  // Corrupted passwords message:
  var subject = 'Please reset your password at ' +
      URL_BASE.toString();
  var msg = 'Your password has been corrupted ' +
            'so please reset it at the link below. ' +
            'Note that no one obtained your password, ' +
            'so you may use the same one you had previously.\n\n' +
            enrollAccountUrl + '\n\n' +
            'Please let us know if you do not have access to '+
            'maps that you could previously see. \n\n' +
            'Thank you and sorry for any inconvenience.'
  */

  var subject = 'An account has been created for you on ' + URL_BASE.toString();
  var msg = subject + '\n' + 'Please set your password within one week at: \n\n' + enrollAccountUrl;
  sendMail(username, subject, msg); // And tell the admin

  msg = "'New user by admin: " + username + ' at ' + URL_BASE.toString() + ' with roles: ' + user.roles;
  sendMail(ADMIN_EMAIL, msg, msg);
}

function createUsers(users) {
  // eslint-disable-line no-unused-vars
  _.each(users, function (user) {
    try {
      var id = Accounts.createUser({
        email: user.email,
        password: "changeMe",
        username: user.email
      }); // Create the user and add the roles to the user's object

      if (user.roles.length > 0) {
        Roles.addUsersToRoles(id, user.roles);
      }

      sendEnrollmentEmail(user.email);
    } catch (error) {
      console.log(`attempting to add user to role since createUser
                failed:`, user.email, error);
      addUsersToRoles([user.email], user.roles);
    }
  });
}

function addUsersToRoles(usernames, roles) {
  // Add users to roles
  // Users must exist
  // Non-existant roles will be created
  // Duplicate roles will be not added
  var users = usernamesToUsers(usernames);

  if (users) {
    console.log('adding users to roles. usernames: ', users, 'roles:', roles);
    Roles.addUsersToRoles(users, roles);
  }
} // eslint-disable-next-line no-unused-vars


function removeUsersFromRoles(usernames, roles) {
  var users = usernamesToUsers(usernames);
  Roles.removeUsersFromRoles(users, roles);
}

function getAllUsernames() {
  // Find all of the usernames
  var users = Meteor.users.find({}, {
    fields: {
      username: 1,
      _id: 0
    }
  }).fetch();
  return _.map(users, function (user) {
    return user.username;
  });
}

function getAllUsers() {
  // Find all of the users.
  return Meteor.users.find({}, {
    fields: {
      username: 1,
      _id: 1
    }
  }).fetch();
}

function showRolesWithUsers() {
  // Show all roles with users in each.
  var roleObjs = Roles.getAllRoles().fetch();

  var roles = _.map(roleObjs, function (role) {
    return role.name;
  });

  console.log('\nRoles with users: ---------------------------');
  var noRoleUsers = getAllUsernames();

  _.each(roles, function (role) {
    var users = Roles.getUsersInRole(role).fetch();

    var usernames = _.map(users, function (user) {
      var index = noRoleUsers.indexOf(user.username);

      if (index > -1) {
        noRoleUsers.splice(index, 1);
      }

      return user.username;
    });

    console.log(role, ': Users:', usernames);
  });
}

function showUsersWithRoles() {
  // Print for each user with her roles.
  console.log('\nUsers with roles: ---------------------------');

  _.each(getAllUsers(), function (user) {
    var roles = Roles.getRolesForUser(user._id);
    console.log(user.username, ': Roles:', roles);
  });
}

console.log( ////////////////////////////////////////////////////
`\nIgnore above warning about bcrypt. It is only for
    passwords and is large.
    We'd rather have faster load times.`);
showRolesWithUsers();
showUsersWithRoles();

function showUsers() {
  // eslint-disable-line no-unused-vars
  // Show all users with their properties
  var users = Meteor.users.find().fetch();
  console.log('all users:\n', users);
}

function showUsernames() {
  // eslint-disable-line no-unused-vars
  // Show all usernames
  console.log('all usernames:\n', getAllUsernames());
}

function removeRoles(role) {
  // eslint-disable-line no-unused-vars
  // Drop all users from the roles and remove the roles.
  if (!role) {
    return;
  }

  var roles = role;

  if (Object.prototype.toString.call(role) === '[object String]') {
    roles = [role];
  }

  var users = Meteor.users.find().fetch();
  Roles.removeUsersFromRoles(users, roles);

  _.each(roles, function (role) {
    Roles.deleteRole(role);
  });
}

function createRole(newRoleName) {
  // eslint-disable-line no-unused-vars
  // Create a role unless it already exists
  var roles = Roles.getAllRoles().fetch();

  var foundRole = _.find(roles, function (role) {
    return role.name === newRoleName;
  });

  if (!foundRole) {
    Roles.createRole(newRoleName);
  }
}

function removeUser(username) {
  // eslint-disable-line no-unused-vars
  var user = usernamesToUsers(username);
  Meteor.users.remove(user);
}

Accounts.onCreateUser(function (options, user) {
  // Add a field of 'username' that meteor recognizes as unique
  user.username = user.emails[0].address; // Send the admin an email.

  var msg = "'New user: " + user.emails[0].address + ' at ' + URL_BASE.toString() + "'";
  sendMail(ADMIN_EMAIL, msg, msg); // Don't forget to return the new user object.

  return user;
});
Meteor.methods({
  getUserAuthorizationRoles: function () {
    // Get the current user's authorization roles.
    var user = Meteor.user();

    if (user === null) {
      return [];
    } else {
      return Roles.getRolesForUser(user._id);
    }
  },
  get_username: function () {
    // Get the username of the current user
    if (Meteor.user()) {
      return Meteor.user().username;
    } else {
      return undefined;
    }
  }
});
Meteor.startup(() => {
  if (Meteor.settings.public.DEV) {
    DEV = true; //development functionality will be included
  } else {
    DEV = false;
  }

  URL_BASE = Meteor.settings.public.URL_BASE; // Allow content from anywhere

  var all = '*:*'; //var kolossus = '*.kolossus.sdsc.edu:*';

  BrowserPolicy.content.allowOriginForAll(all); // We must allow use of evil eval in javascript for google charts.

  BrowserPolicy.content.allowEval(); // Allow content sniffing by google analytics
  //BrowserPolicy.content.allowContentTypeSniffing();
  // From the settings.json file.

  ADMIN_EMAIL = Meteor.settings.public.ADMIN_EMAIL;
  Accounts.emailTemplates.from = ADMIN_EMAIL;
  Accounts.emailTemplates.siteName = 'tumorMap.ucsc.edu';
  exec = Npm.require('child_process').exec;
  process = Npm.require('process');
  userActions();
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"secureRoleTests.js":function(){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/secureRoleTests.js                                                                                       //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
// secureRoleTests.js
// Meteor server code to test role package security
// Note this only tests the Roles package and not our functions in secure.js
function runUnitTests() {
  // eslint-disable-line no-unused-vars
  var failures = 0; // Clear all users

  var count = Meteor.users.remove({}); // eslint-disable-line no-unused-vars
  //console.log('deleteAllUsers: number of users removed:', count);
  // Verify all users are removed

  var users = Meteor.users.find({}).fetch();

  if (users.length > 0) {
    console.log('FAILED: not all users were removed.');
    failures += 1;
  } // Clear all roles


  var roles = Roles.getAllRoles().fetch();
  count = roles.length;

  _.each(roles, function (role) {
    Roles.deleteRole(role.name);
  }); //console.log('deleteAllRoles: number of roles removed:', count);
  // Add users


  users = [{
    username: 'aDeveloper@a.a',
    emails: [{
      address: 'a@a.a'
    }]
  }, {
    username: 'ckccMember@a.a',
    emails: [{
      address: 'b@a.a'
    }]
  }, {
    username: 'admin@a.a',
    emails: [{
      address: 'c@a.a'
    }]
  }];
  var ids = [],
      i = 0;

  for (let user in users) {
    ids[i] = Meteor.users.insert(user);
    console.log('rc on insert of user:', ids[i]); //failures += 1;

    i += 1;
  }

  console.log('ids:', ids); // Verify users added

  var usersAdded = Meteor.users.find().fetch();

  if (usersAdded.length !== 3) {
    console.log('FAILED: users added count is not 3.');
    failures += 1;
  }

  _.each(usersAdded, function (user, i) {
    if (user._id !== ids[i]) {
      console.log('FAILED: user not added:', users[i].username);
      failures += 1;
    }
  }); // Create the public group


  Roles.createRole('public'); // Verify role added

  roles = Roles.getAllRoles().fetch();

  var found = _.find(roles, function (role) {
    return role.name === 'public';
  });

  if (!found) {
    console.log('FAILED: public role was not created');
    failures += 1;
  } // Add users to roles, creating roles as needed. users are user objects?


  Roles.addUsersToRoles(usersAdded[0], 'aDeveloper');
  Roles.addUsersToRoles([usersAdded[0], usersAdded[1]], 'CKCC');
  Roles.addUsersToRoles(usersAdded[2], Roles.GLOBAL_GROUP); // Verify roles added

  var rolesAdded = Roles.getAllRoles().fetch();
  roles = ['aDeveloper', 'CKCC', Roles.GLOBAL_GROUP], _.each(roles, function (role) {
    var found = _.find(rolesAdded, function (added) {
      return added.name === role;
    });

    if (!found) {
      console.log('FAILED:, role not added:', role);
      failures += 1;
    }
  }); // Verify users are added to correct roles
  // Assuming usersAdded & rolesAdded are in the same order as added

  if (!Roles.userIsInRole(usersAdded[0], roles[0])) {
    console.log('FAILED: user not in role: ', usersAdded[0].username, roles[0]);
    failures += 1;
  }

  if (!Roles.userIsInRole(usersAdded[0], roles[1])) {
    console.log('FAILED: user not in role: ', usersAdded[0].username, roles[1]);
    failures += 1;
  }

  if (!Roles.userIsInRole(usersAdded[1], roles[1])) {
    console.log('FAILED: user not in role: ', usersAdded[1].username, roles[1]);
    failures += 1;
  }

  if (!Roles.userIsInRole(usersAdded[2], roles[2])) {
    console.log('FAILED: user not in role: ', usersAdded[2].username, roles[2]);
    failures += 1;
  } // Verify users have the correct number of roles


  var userRoles = Roles.getRolesForUser(usersAdded[0]._id);

  if (userRoles.length !== 2) {
    console.log("FAILED: user's role count should be 2", usersAdded[0].username);
    failures += 1;
  }

  userRoles = Roles.getRolesForUser(usersAdded[1]._id);

  if (userRoles.length !== 1) {
    console.log("FAILED: user's role count should be 1", usersAdded[1].username);
    failures += 1;
  }

  userRoles = Roles.getRolesForUser(usersAdded[2]._id);

  if (userRoles.length !== 1) {
    console.log("FAILED: user's role count should be 1", usersAdded[2].username);
    failures += 1;
  }

  if (failures < 1) console.log('All user tests were successful!');
} //runUnitTests() // turn off when not testing;
// More Example calls ///////////////////////////////////////////////
// Insert a user into the users db table via the login UI
// groupId is equivalent to _id in the db.
// userId is equivalent to _id in the db.

/*
Meteor.call('findUser', 'CYhm7nMLqiRPpWYdX', function (error, user) {
    console.log('user.emails[0].address', user.emails[0].address);
});
*/

/*
// Find all users.
Meteor.call('findAllUsers', function (error, users) {
    _.each(users, function (user) {
        console.log('user', user.emails[0].address, user.username);
    });
});
*/
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});

require("/server/bookmark.js");
require("/server/http.js");
require("/server/secure.js");
require("/server/secureRoleTests.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2Jvb2ttYXJrLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvaHR0cC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3NlY3VyZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3NlY3VyZVJvbGVUZXN0cy5qcyJdLCJuYW1lcyI6WyJDcnlwdG9KUyIsIm1vZHVsZSIsImxpbmsiLCJkZWZhdWx0IiwidiIsIkJvb2ttYXJrcyIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsImh1bWFuVG9kYXkiLCJkYXRlIiwiRGF0ZSIsImludE1vbnRoIiwicGFyc2VJbnQiLCJnZXRNb250aCIsInN0ck1vbnRoIiwidG9TdHJpbmciLCJnZXRGdWxsWWVhciIsImdldERhdGUiLCJjcmVhdGVJZCIsImpzb25TdGF0ZSIsImlkIiwiU0hBMjU2IiwidXJsIiwiVVJMX0JBU0UiLCJleHBvcnRzIiwiY3JlYXRlIiwidXNlcm5hbWUiLCJrZXkiLCJkYlVzZXJuYW1lIiwiYm9va21hcmsiLCJmaW5kT25lIiwiXyIsInVuaXEiLCJjb25jYXQiLCJmaWx0ZXIiLCJCb29sZWFuIiwidXBzZXJ0IiwiX2lkIiwiJHNldCIsImxhc3RBY2Nlc3MiLCJNZXRlb3IiLCJtZXRob2RzIiwiZmluZEJvb2ttYXJrIiwidXNlciIsInVwZGF0ZSIsInVuZGVmaW5lZCIsIkpTT04iLCJwYXJzZSIsImVycm9yIiwiY29uc29sZSIsImxvZyIsInRyYWNlIiwiRXJyb3IiLCJjcmVhdGVCb29rbWFyayIsInJlc3VsdCIsImUiLCJyZXNwb25kIiwic3RhdHVzQ29kZSIsInJlcyIsImRhdGFfaW4iLCJkYXRhIiwic3RyaW5naWZ5Iiwic2V0SGVhZGVyIiwid3JpdGVIZWFkIiwiZW5kIiwicGFzc1Bvc3RDaGVja3MiLCJyZXEiLCJtZXRob2QiLCJoZWFkZXJzIiwicGFyc2VKc29uIiwianNvbkRhdGEiLCJtc2ciLCJ1cGRhdGVCb29rbWFya0RhdGFiYXNlIiwiZW1haWwiLCJoYXNPd25Qcm9wZXJ0eSIsInVwZGF0ZUNvbG9yIiwiQWNjb3VudHMiLCJmaW5kVXNlckJ5VXNlcm5hbWUiLCJ1c2VyRW1haWwiLCJ1c2VyUm9sZSIsIlJvbGVzIiwiZ2V0Um9sZXNGb3JVc2VyIiwiSFVCX1VSTCIsIkhUVFAiLCJjYWxsIiwicmVjZWl2ZVBvc3QiLCJvcGVyYXRpb24iLCJzZXRFbmNvZGluZyIsIm9uIiwiY2h1bmsiLCJlZGl0TWFwR2V0IiwidXJsUGFydHMiLCJzcGxpdCIsImluZGV4T2YiLCJyb2xlcyIsImxlbmd0aCIsImpvaW4iLCJXZWJBcHAiLCJjb25uZWN0SGFuZGxlcnMiLCJ1c2UiLCJzZXR0aW5ncyIsInB1YmxpYyIsInVzZXJBY3Rpb25zIiwiYWRkVXNlcnNUb1JvbGVzIiwic2VuZE1haWwiLCJ1c2VycyIsInN1YmplY3QiLCJjYWxsYmFjayIsImNvbW1hbmQiLCJBRE1JTl9FTUFJTCIsIkRFViIsImV4ZWMiLCJzdGRvdXQiLCJzdGRlcnIiLCJlcnJNc2ciLCJ1c2VybmFtZXNUb1VzZXJzIiwidXNlcm5hbWVzSW4iLCJ1c2VybmFtZXMiLCJhcnJheSIsIm1hcCIsInNlbmRFbnJvbGxtZW50RW1haWwiLCJ0b2tlbiIsIlJhbmRvbSIsInNlY3JldCIsInRva2VuUmVjb3JkIiwid2hlbiIsIl9lbnN1cmUiLCJyZXNldCIsImVucm9sbEFjY291bnRVcmwiLCJ1cmxzIiwiZW5yb2xsQWNjb3VudCIsImNyZWF0ZVVzZXJzIiwiZWFjaCIsImNyZWF0ZVVzZXIiLCJwYXNzd29yZCIsInJlbW92ZVVzZXJzRnJvbVJvbGVzIiwiZ2V0QWxsVXNlcm5hbWVzIiwiZmluZCIsImZpZWxkcyIsImZldGNoIiwiZ2V0QWxsVXNlcnMiLCJzaG93Um9sZXNXaXRoVXNlcnMiLCJyb2xlT2JqcyIsImdldEFsbFJvbGVzIiwicm9sZSIsIm5hbWUiLCJub1JvbGVVc2VycyIsImdldFVzZXJzSW5Sb2xlIiwiaW5kZXgiLCJzcGxpY2UiLCJzaG93VXNlcnNXaXRoUm9sZXMiLCJzaG93VXNlcnMiLCJzaG93VXNlcm5hbWVzIiwicmVtb3ZlUm9sZXMiLCJPYmplY3QiLCJwcm90b3R5cGUiLCJkZWxldGVSb2xlIiwiY3JlYXRlUm9sZSIsIm5ld1JvbGVOYW1lIiwiZm91bmRSb2xlIiwicmVtb3ZlVXNlciIsInJlbW92ZSIsIm9uQ3JlYXRlVXNlciIsIm9wdGlvbnMiLCJlbWFpbHMiLCJhZGRyZXNzIiwiZ2V0VXNlckF1dGhvcml6YXRpb25Sb2xlcyIsImdldF91c2VybmFtZSIsInN0YXJ0dXAiLCJhbGwiLCJCcm93c2VyUG9saWN5IiwiY29udGVudCIsImFsbG93T3JpZ2luRm9yQWxsIiwiYWxsb3dFdmFsIiwiZW1haWxUZW1wbGF0ZXMiLCJmcm9tIiwic2l0ZU5hbWUiLCJOcG0iLCJyZXF1aXJlIiwicHJvY2VzcyIsInJ1blVuaXRUZXN0cyIsImZhaWx1cmVzIiwiY291bnQiLCJpZHMiLCJpIiwiaW5zZXJ0IiwidXNlcnNBZGRlZCIsImZvdW5kIiwiR0xPQkFMX0dST1VQIiwicm9sZXNBZGRlZCIsImFkZGVkIiwidXNlcklzSW5Sb2xlIiwidXNlclJvbGVzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLFFBQUo7QUFBYUMsTUFBTSxDQUFDQyxJQUFQLENBQVksV0FBWixFQUF3QjtBQUFDQyxTQUFPLENBQUNDLENBQUQsRUFBRztBQUFDSixZQUFRLEdBQUNJLENBQVQ7QUFBVzs7QUFBdkIsQ0FBeEIsRUFBaUQsQ0FBakQ7QUFLYixJQUFJQyxTQUFTLEdBQUcsSUFBSUMsS0FBSyxDQUFDQyxVQUFWLENBQXFCLFdBQXJCLENBQWhCOztBQUVBLFNBQVNDLFVBQVQsR0FBdUI7QUFDbkIsTUFBSUMsSUFBSSxHQUFHLElBQUlDLElBQUosRUFBWDtBQUFBLE1BQ0lDLFFBQVEsR0FBR0MsUUFBUSxDQUFDSCxJQUFJLENBQUNJLFFBQUwsRUFBRCxDQUFSLEdBQTRCLENBRDNDO0FBQUEsTUFFSUMsUUFBUSxHQUFJSCxRQUFRLEdBQUcsRUFBWixHQUNQLE1BQU1BLFFBQVEsQ0FBQ0ksUUFBVCxFQURDLEdBQ3FCSixRQUFRLENBQUNJLFFBQVQsRUFIcEM7QUFJQSxTQUFPTixJQUFJLENBQUNPLFdBQUwsS0FBcUIsR0FBckIsR0FBMkJGLFFBQTNCLEdBQXNDLEdBQXRDLEdBQTRDTCxJQUFJLENBQUNRLE9BQUwsRUFBbkQ7QUFDSDs7QUFFRCxTQUFTQyxRQUFULENBQW1CQyxTQUFuQixFQUE4QjtBQUUxQjtBQUNBLE1BQUlDLEVBQUUsR0FBR3BCLFFBQVEsQ0FBQ3FCLE1BQVQsQ0FBZ0JGLFNBQWhCLEVBQTJCSixRQUEzQixFQUFUO0FBQ0EsU0FBTztBQUNISyxNQUFFLEVBQUVBLEVBREQ7QUFFSEUsT0FBRyxFQUFFQyxRQUFRLEdBQUcsYUFBWCxHQUEyQkg7QUFGN0IsR0FBUDtBQUlIOztBQUVESSxPQUFPLENBQUNDLE1BQVIsR0FBaUIsVUFBVU4sU0FBVixFQUFxQk8sUUFBckIsRUFBK0I7QUFFNUM7QUFDQSxNQUFJQyxHQUFHLEdBQUdULFFBQVEsQ0FBQ0MsU0FBRCxDQUFsQjtBQUFBLE1BQ0lTLFVBQVUsR0FBR0YsUUFEakI7QUFBQSxNQUVJRyxRQUFRLEdBQUd4QixTQUFTLENBQUN5QixPQUFWLENBQWtCSCxHQUFHLENBQUNQLEVBQUosQ0FBT0wsUUFBUCxFQUFsQixDQUZmLENBSDRDLENBTzVDOztBQUNBLE1BQUljLFFBQUosRUFBYztBQUVWO0FBQ0E7QUFDQUQsY0FBVSxHQUFHRyxDQUFDLENBQUNDLElBQUYsQ0FBTyxHQUFHQyxNQUFILENBQVVKLFFBQVEsQ0FBQ0gsUUFBbkIsRUFBNkJBLFFBQTdCLEVBQ2ZRLE1BRGUsQ0FDUkMsT0FEUSxDQUFQLENBQWI7QUFFSCxHQWQyQyxDQWdCNUM7OztBQUNBOUIsV0FBUyxDQUFDK0IsTUFBVixDQUFpQjtBQUFFQyxPQUFHLEVBQUVWLEdBQUcsQ0FBQ1A7QUFBWCxHQUFqQixFQUNJO0FBQUNrQixRQUFJLEVBQUU7QUFDSG5CLGVBQVMsRUFBRUEsU0FEUjtBQUVITyxjQUFRLEVBQUVFLFVBRlA7QUFHSFcsZ0JBQVUsRUFBRS9CLFVBQVU7QUFIbkI7QUFBUCxHQURKO0FBUUEsU0FBTztBQUFFcUIsWUFBUSxFQUFFRixHQUFHLENBQUNMO0FBQWhCLEdBQVA7QUFDSCxDQTFCRDs7QUE0QkFrQixNQUFNLENBQUNDLE9BQVAsQ0FBZTtBQUNYQyxjQUFZLEVBQUUsVUFBVXRCLEVBQVYsRUFBYztBQUN4QixRQUFJO0FBQ0EsVUFBSVMsUUFBUSxHQUFHeEIsU0FBUyxDQUFDeUIsT0FBVixDQUFrQlYsRUFBRSxDQUFDTCxRQUFILEVBQWxCLENBQWY7QUFBQSxVQUNJNEIsSUFBSSxHQUFHSCxNQUFNLENBQUNHLElBQVAsRUFEWDs7QUFHQSxVQUFJLENBQUNkLFFBQUwsRUFBZTtBQUNYLGVBQU8sb0JBQVA7QUFDSCxPQU5ELENBUUE7OztBQUNBeEIsZUFBUyxDQUFDdUMsTUFBVixDQUFpQnhCLEVBQWpCLEVBQXFCO0FBQ2pCa0IsWUFBSSxFQUFFO0FBQ0ZaLGtCQUFRLEVBQUVpQixJQUFJLEdBQUdBLElBQUksQ0FBQ2pCLFFBQVIsR0FBbUJtQixTQUQvQjtBQUVGTixvQkFBVSxFQUFFL0IsVUFBVTtBQUZwQjtBQURXLE9BQXJCO0FBTUEsYUFBT3NDLElBQUksQ0FBQ0MsS0FBTCxDQUFXbEIsUUFBUSxDQUFDVixTQUFwQixDQUFQO0FBRUgsS0FqQkQsQ0FpQkUsT0FBTzZCLEtBQVAsRUFBYztBQUVaQyxhQUFPLENBQUNDLEdBQVIsQ0FBWSw2QkFBWixFQUEyQ0YsS0FBSyxDQUFDakMsUUFBTixFQUEzQztBQUNBa0MsYUFBTyxDQUFDRSxLQUFSO0FBQ0EsWUFBTSxJQUFJWCxNQUFNLENBQUNZLEtBQVgsQ0FBaUIseUJBQWpCLEVBQTRDSixLQUFLLENBQUNqQyxRQUFOLEVBQTVDLENBQU47QUFDSDtBQUNKLEdBekJVO0FBMkJYc0MsZ0JBQWMsRUFBRSxVQUFVbEMsU0FBVixFQUFxQjtBQUVqQztBQUNBLFFBQUk7QUFDQSxVQUFJd0IsSUFBSSxHQUFHSCxNQUFNLENBQUNHLElBQVAsRUFBWDtBQUFBLFVBQ0lXLE1BQU0sR0FBRzlCLE9BQU8sQ0FBQ0MsTUFBUixDQUNMTixTQURLLEVBQ013QixJQUFJLEdBQUdBLElBQUksQ0FBQ2pCLFFBQVIsR0FBbUJtQixTQUQ3QixDQURiO0FBR0EsYUFBT1MsTUFBTSxDQUFDekIsUUFBZDtBQUVILEtBTkQsQ0FNRSxPQUFPMEIsQ0FBUCxFQUFVO0FBQ1JOLGFBQU8sQ0FBQ0MsR0FBUixDQUFZLDZCQUFaLEVBQTJDSyxDQUFDLENBQUN4QyxRQUFGLEVBQTNDO0FBQ0FrQyxhQUFPLENBQUNFLEtBQVI7QUFDQSxZQUFNLElBQUlYLE1BQU0sQ0FBQ1ksS0FBWCxDQUFpQiwyQkFBakIsRUFBOENHLENBQUMsQ0FBQ3hDLFFBQUYsRUFBOUMsQ0FBTjtBQUNIO0FBQ0o7QUF6Q1UsQ0FBZixFOzs7Ozs7Ozs7OztBQ3JEQSxJQUFJYyxRQUFKO0FBQWE1QixNQUFNLENBQUNDLElBQVAsQ0FBWSxZQUFaLEVBQXlCO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUN5QixZQUFRLEdBQUN6QixDQUFUO0FBQVc7O0FBQXZCLENBQXpCLEVBQWtELENBQWxEOztBQU1iLFNBQVNvRCxPQUFULENBQWtCQyxVQUFsQixFQUE4QkMsR0FBOUIsRUFBbUNDLE9BQW5DLEVBQTRDO0FBRXhDO0FBQ0EsTUFBSUMsSUFBSSxHQUFHZCxJQUFJLENBQUNlLFNBQUwsQ0FBZUYsT0FBZixDQUFYO0FBQ0FELEtBQUcsQ0FBQ0ksU0FBSixDQUFjLGNBQWQsRUFBOEIsa0JBQTlCO0FBQ0FKLEtBQUcsQ0FBQ0ssU0FBSixDQUFjTixVQUFkO0FBQ0FDLEtBQUcsQ0FBQ00sR0FBSixDQUFRSixJQUFJLEdBQUcsSUFBZjtBQUNIOztBQUVELFNBQVNLLGNBQVQsQ0FBeUJDLEdBQXpCLEVBQThCUixHQUE5QixFQUFtQztBQUUvQjtBQUNBO0FBRUE7QUFDQSxNQUFJUSxHQUFHLENBQUNDLE1BQUosS0FBZSxNQUFuQixFQUEyQjtBQUN2QlgsV0FBTyxDQUFDLEdBQUQsRUFBTUUsR0FBTixFQUFXLHlDQUFYLENBQVA7QUFDSCxHQVI4QixDQVUvQjs7O0FBQ0EsTUFBSVEsR0FBRyxDQUFDRSxPQUFKLENBQVksY0FBWixNQUFnQyxrQkFBcEMsRUFBd0Q7QUFDcERaLFdBQU8sQ0FBQyxHQUFELEVBQU1FLEdBQU4sRUFDSCwwREFERyxDQUFQO0FBRUg7QUFDSjs7QUFFRCxTQUFTVyxTQUFULENBQW9CQyxRQUFwQixFQUE4QlosR0FBOUIsRUFBbUM7QUFFL0I7QUFDQSxNQUFJRSxJQUFJLEdBQUcsSUFBWDs7QUFDQSxNQUFJO0FBQ0FBLFFBQUksR0FBR2QsSUFBSSxDQUFDQyxLQUFMLENBQVd1QixRQUFYLENBQVA7QUFDSCxHQUZELENBRUUsT0FBT2YsQ0FBUCxFQUFVO0FBQ1IsUUFBSWdCLEdBQUcsR0FBRyxpQ0FBaUNoQixDQUEzQztBQUNBQyxXQUFPLENBQUMsR0FBRCxFQUFNRSxHQUFOLEVBQVc7QUFBQ1YsV0FBSyxFQUFFdUI7QUFBUixLQUFYLENBQVA7QUFDQTtBQUNIOztBQUNELFNBQU9YLElBQVA7QUFDSDs7QUFFRCxTQUFlWSxzQkFBZixDQUF1Q3JELFNBQXZDLEVBQWtEc0QsS0FBbEQsRUFBeURmLEdBQXpEO0FBQUEsa0NBQThEO0FBQzFELFFBQUk7QUFDQSxVQUFJSixNQUFNLGlCQUFTekIsUUFBUSxDQUFDSixNQUFULENBQWdCTixTQUFoQixFQUEyQnNELEtBQTNCLENBQVQsQ0FBVjtBQUNBakIsYUFBTyxDQUFDLEdBQUQsRUFBTUUsR0FBTixFQUFXSixNQUFYLENBQVA7QUFDSCxLQUhELENBR0UsT0FBT04sS0FBUCxFQUFjO0FBQ1pRLGFBQU8sQ0FBQyxHQUFELEVBQU1FLEdBQU4sRUFBVztBQUFFVixhQUFLLEVBQUVBO0FBQVQsT0FBWCxDQUFQO0FBQ0g7QUFDSixHQVBEO0FBQUE7O0FBU0EsU0FBU0ssY0FBVCxDQUF5QmlCLFFBQXpCLEVBQW1DSixHQUFuQyxFQUF3Q1IsR0FBeEMsRUFBNkM7QUFDekMsTUFBSUUsSUFBSSxHQUFHUyxTQUFTLENBQUNDLFFBQUQsRUFBV1osR0FBWCxDQUFwQjtBQUFBLE1BQ0l2QyxTQUFTLEdBQUdtRCxRQURoQjtBQUFBLE1BRUlHLEtBQUssR0FBRyxJQUZaLENBRHlDLENBS3pDOztBQUNBLE1BQUliLElBQUksQ0FBQ2MsY0FBTCxDQUFvQixPQUFwQixDQUFKLEVBQWtDO0FBQzlCRCxTQUFLLEdBQUdiLElBQUksQ0FBQ2EsS0FBYjtBQUNBLFdBQU9iLElBQUksQ0FBQ2EsS0FBWjtBQUNBdEQsYUFBUyxHQUFHMkIsSUFBSSxDQUFDZSxTQUFMLENBQWVELElBQWYsQ0FBWjtBQUNIOztBQUVEWSx3QkFBc0IsQ0FBQ3JELFNBQUQsRUFBWXNELEtBQVosRUFBbUJmLEdBQW5CLENBQXRCO0FBQ0g7O0FBRUQsU0FBZWlCLFdBQWYsQ0FBNEJMLFFBQTVCLEVBQXNDSixHQUF0QyxFQUEyQ1IsR0FBM0M7QUFBQSxrQ0FBZ0Q7QUFDNUMsUUFBSUUsSUFBSSxHQUFHUyxTQUFTLENBQUNDLFFBQUQsRUFBV1osR0FBWCxDQUFwQjs7QUFDQSxRQUFJO0FBQ0EsVUFBSWYsSUFBSSxpQkFBU2lDLFFBQVEsQ0FBQ0Msa0JBQVQsQ0FBNEJqQixJQUFJLENBQUNrQixTQUFqQyxDQUFULENBQVI7QUFDQWxCLFVBQUksQ0FBQ21CLFFBQUwsR0FBZ0JDLEtBQUssQ0FBQ0MsZUFBTixDQUFzQnRDLElBQUksQ0FBQ04sR0FBM0IsQ0FBaEIsQ0FGQSxDQUlBOztBQUNBLFVBQUlmLEdBQUcsR0FBRzRELE9BQU8sR0FBRyxjQUFwQjtBQUNBQyxVQUFJLENBQUNDLElBQUwsQ0FBVSxNQUFWLEVBQWtCOUQsR0FBbEIsRUFBdUI7QUFBQ3NDLFlBQUksRUFBRUE7QUFBUCxPQUF2QixFQUFxQyxDQUFDWixLQUFELEVBQVFNLE1BQVIsS0FBbUI7QUFDcEQsWUFBSU4sS0FBSixFQUFXO0FBQ1BRLGlCQUFPLENBQUMsR0FBRCxFQUFNRSxHQUFOLEVBQVdKLE1BQU0sQ0FBQ00sSUFBbEIsQ0FBUDtBQUNILFNBRkQsTUFFTztBQUNISixpQkFBTyxDQUFDLEdBQUQsRUFBTUUsR0FBTixFQUFXSixNQUFNLENBQUNNLElBQWxCLENBQVA7QUFDSDtBQUNKLE9BTkQ7QUFPSCxLQWJELENBYUUsT0FBT1osS0FBUCxFQUFjO0FBQ1pRLGFBQU8sQ0FBQyxHQUFELEVBQU1FLEdBQU4sRUFBVztBQUFFVixhQUFLLEVBQUVBO0FBQVQsT0FBWCxDQUFQO0FBQ0g7QUFDSixHQWxCRDtBQUFBOztBQW9CQSxTQUFTcUMsV0FBVCxDQUFzQkMsU0FBdEIsRUFBaUNwQixHQUFqQyxFQUFzQ1IsR0FBdEMsRUFBMkM7QUFFdkM7QUFFQU8sZ0JBQWMsQ0FBQ0MsR0FBRCxFQUFNUixHQUFOLENBQWQ7QUFDQSxNQUFJWSxRQUFRLEdBQUcsRUFBZjtBQUVBSixLQUFHLENBQUNxQixXQUFKLENBQWdCLE1BQWhCLEVBUHVDLENBU3ZDOztBQUNBckIsS0FBRyxDQUFDc0IsRUFBSixDQUFPLE1BQVAsRUFBZSxVQUFVQyxLQUFWLEVBQWlCO0FBQzVCbkIsWUFBUSxJQUFJbUIsS0FBWjtBQUNILEdBRkQsRUFWdUMsQ0FjdkM7O0FBQ0F2QixLQUFHLENBQUNzQixFQUFKLENBQU8sS0FBUCxFQUFjLFlBQVk7QUFDdEIsUUFBSUYsU0FBUyxLQUFLLGdCQUFsQixFQUFvQztBQUNoQ2pDLG9CQUFjLENBQUNpQixRQUFELEVBQVdKLEdBQVgsRUFBZ0JSLEdBQWhCLENBQWQ7QUFDSCxLQUZELE1BRU8sSUFBSTRCLFNBQVMsS0FBSyxhQUFsQixFQUFpQztBQUNwQ1gsaUJBQVcsQ0FBQ0wsUUFBRCxFQUFXSixHQUFYLEVBQWdCUixHQUFoQixDQUFYO0FBQ0gsS0FGTSxNQUVBO0FBQ0hGLGFBQU8sQ0FBQyxHQUFELEVBQU1FLEdBQU4sRUFDSDtBQUFDVixhQUFLLEVBQUUsb0NBQW9Dc0M7QUFBNUMsT0FERyxDQUFQO0FBRUg7QUFDSixHQVREO0FBVUg7O0FBRUQsU0FBU0ksVUFBVCxDQUFxQkosU0FBckIsRUFBZ0NwQixHQUFoQyxFQUFxQ1IsR0FBckMsRUFBMEM7QUFFdEM7QUFFQTtBQUNBLE1BQUlpQyxRQUFRLEdBQUd6QixHQUFHLENBQUM1QyxHQUFKLENBQVFzRSxLQUFSLENBQWMsR0FBZCxDQUFmO0FBQ0EsTUFBSWxFLFFBQVEsR0FBR2lFLFFBQVEsQ0FBQ0EsUUFBUSxDQUFDRSxPQUFULENBQWlCLE9BQWpCLElBQTRCLENBQTdCLENBQXZCLENBTnNDLENBUXRDOztBQUNBLE1BQUlsRCxJQUFJLEdBQUdpQyxRQUFRLENBQUNDLGtCQUFULENBQTRCbkQsUUFBNUIsQ0FBWDtBQUNBLE1BQUlvRSxLQUFLLEdBQUdkLEtBQUssQ0FBQ0MsZUFBTixDQUFzQnRDLElBQUksQ0FBQ04sR0FBM0IsQ0FBWjtBQUVBLE1BQUlmLEdBQUcsR0FBRzRELE9BQU8sR0FBRyxHQUFWLEdBQWdCSSxTQUFoQixHQUE0QnBCLEdBQUcsQ0FBQzVDLEdBQTFDOztBQUNBLE1BQUl3RSxLQUFLLENBQUNDLE1BQU4sR0FBZSxDQUFuQixFQUFzQjtBQUNsQnpFLE9BQUcsSUFBSSxXQUFXd0UsS0FBSyxDQUFDRSxJQUFOLENBQVcsR0FBWCxDQUFsQjtBQUNILEdBZnFDLENBaUJ0Qzs7O0FBQ0FiLE1BQUksQ0FBQ0MsSUFBTCxDQUFVLEtBQVYsRUFBaUI5RCxHQUFqQixFQUFzQixDQUFDMEIsS0FBRCxFQUFRTSxNQUFSLEtBQW1CO0FBQ3JDLFFBQUlOLEtBQUosRUFBVztBQUNQUSxhQUFPLENBQUMsR0FBRCxFQUFNRSxHQUFOLEVBQVdWLEtBQVgsQ0FBUDtBQUNILEtBRkQsTUFFTztBQUNIUSxhQUFPLENBQUMsR0FBRCxFQUFNRSxHQUFOLEVBQVdKLE1BQU0sQ0FBQ00sSUFBbEIsQ0FBUDtBQUNIO0FBQ0osR0FORDtBQU9IOztBQUVEcUMsTUFBTSxDQUFDQyxlQUFQLENBQXVCQyxHQUF2QixDQUEyQixPQUEzQixFQUFvQyxVQUFVakMsR0FBVixFQUFlUixHQUFmLEVBQW9CO0FBQ3BERixTQUFPLENBQUMsR0FBRCxFQUFNRSxHQUFOLEVBQVcsY0FBWCxDQUFQO0FBQ0gsQ0FGRDtBQUlBdUMsTUFBTSxDQUFDQyxlQUFQLENBQXVCQyxHQUF2QixDQUEyQix1QkFBM0IsRUFBb0QsVUFBVWpDLEdBQVYsRUFBZVIsR0FBZixFQUFvQjtBQUNwRTJCLGFBQVcsQ0FBQyxnQkFBRCxFQUFtQm5CLEdBQW5CLEVBQXdCUixHQUF4QixDQUFYO0FBQ0gsQ0FGRCxFLENBSUE7O0FBQ0F1QyxNQUFNLENBQUNDLGVBQVAsQ0FBdUJDLEdBQXZCLENBQTJCLFlBQTNCLEVBQXlDLFVBQVVqQyxHQUFWLEVBQWVSLEdBQWYsRUFBb0I7QUFDekRnQyxZQUFVLENBQUMsV0FBRCxFQUFjeEIsR0FBZCxFQUFtQlIsR0FBbkIsQ0FBVjtBQUNILENBRkQ7QUFJQXVDLE1BQU0sQ0FBQ0MsZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkIsY0FBM0IsRUFBMkMsVUFBVWpDLEdBQVYsRUFBZVIsR0FBZixFQUFvQjtBQUMzRDJCLGFBQVcsQ0FBQyxhQUFELEVBQWdCbkIsR0FBaEIsRUFBcUJSLEdBQXJCLENBQVg7QUFDSCxDQUZEO0FBSUF3QixPQUFPLEdBQUcxQyxNQUFNLENBQUM0RCxRQUFQLENBQWdCQyxNQUFoQixDQUF1Qm5CLE9BQWpDLEM7Ozs7Ozs7Ozs7O0FDaEtBO0FBRUE7QUFDQTtBQUVBLFNBQVNvQixXQUFULEdBQXdCO0FBRXBCO0FBQ0E7QUFDQTtBQUNBO0FBQ0FDLGlCQUFlLENBQUUsQ0FBQyxtQkFBRCxDQUFGLEVBQTBCLENBQUMsTUFBRCxDQUExQixDQUFmLENBTm9CLENBT3BCOztBQUNBOzs7Ozs7QUFNSDs7QUFFRCxTQUFTQyxRQUFULENBQW1CQyxLQUFuQixFQUEwQkMsT0FBMUIsRUFBbUNuQyxHQUFuQyxFQUF3Q29DLFFBQXhDLEVBQWtEO0FBRTlDO0FBQ0E7QUFDQSxNQUFJQyxPQUFPLEdBQ1AsV0FDRXJDLEdBREYsR0FFRSxNQUZGLEdBR0UsV0FIRixHQUlFbUMsT0FKRixHQUtFLGFBTEYsR0FNRUcsV0FORixHQU9FLElBUEYsR0FRRUosS0FBSyxDQUFDMUYsUUFBTixFQVROOztBQVdBLE1BQUkrRixHQUFKLEVBQVM7QUFDTDdELFdBQU8sQ0FBQ0MsR0FBUixDQUFZLGFBQVosRUFBMkIwRCxPQUEzQjtBQUNBO0FBQ0g7QUFFRDs7O0FBQ0FHLE1BQUksQ0FBQ0gsT0FBRCxFQUFVLFVBQVU1RCxLQUFWLEVBQWlCZ0UsTUFBakIsRUFBeUJDLE1BQXpCLEVBQWlDO0FBQzNDLFFBQUlqRSxLQUFKLEVBQVc7QUFDUCxVQUFJa0UsTUFBTSxHQUFHLDBCQUEwQmxFLEtBQXZDO0FBQ0FDLGFBQU8sQ0FBQ0MsR0FBUixDQUFZZ0UsTUFBWjs7QUFDQSxVQUFJUCxRQUFKLEVBQWM7QUFBRUEsZ0JBQVEsQ0FBQ08sTUFBRCxDQUFSO0FBQW1CO0FBQ3RDLEtBSkQsTUFJTztBQUNILFVBQUlQLFFBQUosRUFBYztBQUFFQSxnQkFBUTtBQUFLO0FBQ2hDO0FBQ0osR0FSRyxDQUFKO0FBU0g7O0FBRUQsU0FBU1EsZ0JBQVQsQ0FBMkJDLFdBQTNCLEVBQXdDO0FBQ3BDLE1BQUlDLFNBQVMsR0FBR0QsV0FBaEI7O0FBQ0EsTUFBSSxPQUFPQyxTQUFQLEtBQXFCLFFBQXpCLEVBQW1DO0FBQy9CQSxhQUFTLEdBQUcsQ0FBQ0QsV0FBRCxDQUFaO0FBQ0g7O0FBQ0QsTUFBSUUsS0FBSyxHQUFHdkYsQ0FBQyxDQUFDd0YsR0FBRixDQUFNRixTQUFOLEVBQWlCLFVBQVUzRixRQUFWLEVBQW9CO0FBQzdDLFdBQU9rRCxRQUFRLENBQUNDLGtCQUFULENBQTRCbkQsUUFBNUIsQ0FBUDtBQUNILEdBRlcsQ0FBWjs7QUFHQSxNQUFJLE9BQU8wRixXQUFQLEtBQXVCLFFBQTNCLEVBQXFDO0FBQ2pDLFdBQU9FLEtBQUssQ0FBQyxDQUFELENBQVo7QUFDSDs7QUFDRCxTQUFPQSxLQUFQO0FBQ0g7O0FBRUQsU0FBU0UsbUJBQVQsQ0FBNkI5RixRQUE3QixFQUF1QztBQUNuQyxNQUFJaUIsSUFBSSxHQUFHd0UsZ0JBQWdCLENBQUN6RixRQUFELENBQTNCO0FBQ0EsTUFBSStGLEtBQUssR0FBR0MsTUFBTSxDQUFDQyxNQUFQLEVBQVo7QUFDQSxNQUFJbEgsSUFBSSxHQUFHLElBQUlDLElBQUosRUFBWDtBQUNBLE1BQUlrSCxXQUFXLEdBQUc7QUFDZEgsU0FBSyxFQUFFQSxLQURPO0FBRWRoRCxTQUFLLEVBQUU5QixJQUFJLENBQUNqQixRQUZFO0FBR2RtRyxRQUFJLEVBQUVwSDtBQUhRLEdBQWxCO0FBS0ErQixRQUFNLENBQUNpRSxLQUFQLENBQWE3RCxNQUFiLENBQW9CRCxJQUFJLENBQUNOLEdBQXpCLEVBQThCO0FBQUNDLFFBQUksRUFBRTtBQUNqQyxpQ0FBMkJzRjtBQURNO0FBQVAsR0FBOUIsRUFUbUMsQ0FhbkM7O0FBQ0FwRixRQUFNLENBQUNzRixPQUFQLENBQWVuRixJQUFmLEVBQXFCLFVBQXJCLEVBQWlDLFVBQWpDLEVBQTZDb0YsS0FBN0MsR0FBcURILFdBQXJEO0FBQ0EsTUFBSUksZ0JBQWdCLEdBQUdwRCxRQUFRLENBQUNxRCxJQUFULENBQWNDLGFBQWQsQ0FBNEJULEtBQTVCLENBQXZCO0FBRUE7Ozs7Ozs7Ozs7Ozs7O0FBY0EsTUFBSWYsT0FBTyxHQUFHLDRDQUNWbkYsUUFBUSxDQUFDUixRQUFULEVBREo7QUFFQSxNQUFJd0QsR0FBRyxHQUFHbUMsT0FBTyxHQUFHLElBQVYsR0FDQSxtREFEQSxHQUVBc0IsZ0JBRlY7QUFJQXhCLFVBQVEsQ0FBQzlFLFFBQUQsRUFBV2dGLE9BQVgsRUFBb0JuQyxHQUFwQixDQUFSLENBckNtQyxDQXVDbkM7O0FBQ0FBLEtBQUcsR0FBRyx5QkFDRjdDLFFBREUsR0FFRixNQUZFLEdBR0ZILFFBQVEsQ0FBQ1IsUUFBVCxFQUhFLEdBSUYsZUFKRSxHQUtGNEIsSUFBSSxDQUFDbUQsS0FMVDtBQU1BVSxVQUFRLENBQUNLLFdBQUQsRUFBY3RDLEdBQWQsRUFBbUJBLEdBQW5CLENBQVI7QUFDSDs7QUFFRCxTQUFTNEQsV0FBVCxDQUFxQjFCLEtBQXJCLEVBQTRCO0FBQUU7QUFDMUIxRSxHQUFDLENBQUNxRyxJQUFGLENBQU8zQixLQUFQLEVBQWMsVUFBVTlELElBQVYsRUFBZ0I7QUFDMUIsUUFBSTtBQUNBLFVBQUl2QixFQUFFLEdBQUd3RCxRQUFRLENBQUN5RCxVQUFULENBQW9CO0FBQ3pCNUQsYUFBSyxFQUFFOUIsSUFBSSxDQUFDOEIsS0FEYTtBQUV6QjZELGdCQUFRLEVBQUUsVUFGZTtBQUd6QjVHLGdCQUFRLEVBQUVpQixJQUFJLENBQUM4QjtBQUhVLE9BQXBCLENBQVQsQ0FEQSxDQU9BOztBQUNBLFVBQUk5QixJQUFJLENBQUNtRCxLQUFMLENBQVdDLE1BQVgsR0FBb0IsQ0FBeEIsRUFBMkI7QUFDdkJmLGFBQUssQ0FBQ3VCLGVBQU4sQ0FBc0JuRixFQUF0QixFQUEwQnVCLElBQUksQ0FBQ21ELEtBQS9CO0FBQ0g7O0FBQ0QwQix5QkFBbUIsQ0FBQzdFLElBQUksQ0FBQzhCLEtBQU4sQ0FBbkI7QUFFSCxLQWJELENBYUUsT0FBT3pCLEtBQVAsRUFBYztBQUNaQyxhQUFPLENBQUNDLEdBQVIsQ0FBYTt3QkFBYixFQUNlUCxJQUFJLENBQUM4QixLQURwQixFQUMyQnpCLEtBRDNCO0FBRUF1RCxxQkFBZSxDQUFDLENBQUM1RCxJQUFJLENBQUM4QixLQUFOLENBQUQsRUFBZ0I5QixJQUFJLENBQUNtRCxLQUFyQixDQUFmO0FBQ0g7QUFDSixHQW5CRDtBQW9CSDs7QUFFRCxTQUFTUyxlQUFULENBQTBCYyxTQUExQixFQUFxQ3ZCLEtBQXJDLEVBQTRDO0FBRXhDO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBSVcsS0FBSyxHQUFHVSxnQkFBZ0IsQ0FBQ0UsU0FBRCxDQUE1Qjs7QUFDQSxNQUFJWixLQUFKLEVBQVc7QUFDUHhELFdBQU8sQ0FBQ0MsR0FBUixDQUNJLG9DQURKLEVBQzBDdUQsS0FEMUMsRUFDaUQsUUFEakQsRUFDMkRYLEtBRDNEO0FBRUFkLFNBQUssQ0FBQ3VCLGVBQU4sQ0FBc0JFLEtBQXRCLEVBQTZCWCxLQUE3QjtBQUNIO0FBQ0osQyxDQUVEOzs7QUFDQSxTQUFTeUMsb0JBQVQsQ0FBOEJsQixTQUE5QixFQUF5Q3ZCLEtBQXpDLEVBQWdEO0FBRTVDLE1BQUlXLEtBQUssR0FBR1UsZ0JBQWdCLENBQUNFLFNBQUQsQ0FBNUI7QUFDQXJDLE9BQUssQ0FBQ3VELG9CQUFOLENBQTJCOUIsS0FBM0IsRUFBa0NYLEtBQWxDO0FBQ0g7O0FBRUQsU0FBUzBDLGVBQVQsR0FBNEI7QUFFeEI7QUFDQSxNQUFJL0IsS0FBSyxHQUFHakUsTUFBTSxDQUFDaUUsS0FBUCxDQUFhZ0MsSUFBYixDQUFrQixFQUFsQixFQUFzQjtBQUFDQyxVQUFNLEVBQUU7QUFBQ2hILGNBQVEsRUFBRSxDQUFYO0FBQWNXLFNBQUcsRUFBRTtBQUFuQjtBQUFULEdBQXRCLEVBQXVEc0csS0FBdkQsRUFBWjtBQUNBLFNBQU81RyxDQUFDLENBQUN3RixHQUFGLENBQU1kLEtBQU4sRUFBYSxVQUFVOUQsSUFBVixFQUFnQjtBQUNoQyxXQUFPQSxJQUFJLENBQUNqQixRQUFaO0FBQ0gsR0FGTSxDQUFQO0FBR0g7O0FBRUQsU0FBU2tILFdBQVQsR0FBd0I7QUFFcEI7QUFDQSxTQUFPcEcsTUFBTSxDQUFDaUUsS0FBUCxDQUFhZ0MsSUFBYixDQUFrQixFQUFsQixFQUFzQjtBQUFDQyxVQUFNLEVBQUU7QUFBQ2hILGNBQVEsRUFBRSxDQUFYO0FBQWNXLFNBQUcsRUFBRTtBQUFuQjtBQUFULEdBQXRCLEVBQXVEc0csS0FBdkQsRUFBUDtBQUNIOztBQUVELFNBQVNFLGtCQUFULEdBQThCO0FBRTFCO0FBQ0EsTUFBSUMsUUFBUSxHQUFHOUQsS0FBSyxDQUFDK0QsV0FBTixHQUFvQkosS0FBcEIsRUFBZjs7QUFDQSxNQUFJN0MsS0FBSyxHQUFHL0QsQ0FBQyxDQUFDd0YsR0FBRixDQUFNdUIsUUFBTixFQUFnQixVQUFTRSxJQUFULEVBQWU7QUFDdkMsV0FBT0EsSUFBSSxDQUFDQyxJQUFaO0FBQ0gsR0FGVyxDQUFaOztBQUlBaEcsU0FBTyxDQUFDQyxHQUFSLENBQVksaURBQVo7QUFDQSxNQUFJZ0csV0FBVyxHQUFHVixlQUFlLEVBQWpDOztBQUNBekcsR0FBQyxDQUFDcUcsSUFBRixDQUFPdEMsS0FBUCxFQUFjLFVBQVVrRCxJQUFWLEVBQWdCO0FBQzFCLFFBQUl2QyxLQUFLLEdBQUd6QixLQUFLLENBQUNtRSxjQUFOLENBQXFCSCxJQUFyQixFQUEyQkwsS0FBM0IsRUFBWjs7QUFDQSxRQUFJdEIsU0FBUyxHQUFHdEYsQ0FBQyxDQUFDd0YsR0FBRixDQUFNZCxLQUFOLEVBQWEsVUFBVTlELElBQVYsRUFBZ0I7QUFDekMsVUFBSXlHLEtBQUssR0FBR0YsV0FBVyxDQUFDckQsT0FBWixDQUFvQmxELElBQUksQ0FBQ2pCLFFBQXpCLENBQVo7O0FBQ0EsVUFBSTBILEtBQUssR0FBRyxDQUFDLENBQWIsRUFBZ0I7QUFDWkYsbUJBQVcsQ0FBQ0csTUFBWixDQUFtQkQsS0FBbkIsRUFBMEIsQ0FBMUI7QUFDSDs7QUFDRCxhQUFPekcsSUFBSSxDQUFDakIsUUFBWjtBQUNILEtBTmUsQ0FBaEI7O0FBT0F1QixXQUFPLENBQUNDLEdBQVIsQ0FBWThGLElBQVosRUFBa0IsVUFBbEIsRUFBOEIzQixTQUE5QjtBQUNILEdBVkQ7QUFZSDs7QUFFRCxTQUFTaUMsa0JBQVQsR0FBK0I7QUFFM0I7QUFDQXJHLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLGlEQUFaOztBQUNBbkIsR0FBQyxDQUFDcUcsSUFBRixDQUFPUSxXQUFXLEVBQWxCLEVBQXNCLFVBQVVqRyxJQUFWLEVBQWdCO0FBQ2xDLFFBQUltRCxLQUFLLEdBQUdkLEtBQUssQ0FBQ0MsZUFBTixDQUFzQnRDLElBQUksQ0FBQ04sR0FBM0IsQ0FBWjtBQUNBWSxXQUFPLENBQUNDLEdBQVIsQ0FBWVAsSUFBSSxDQUFDakIsUUFBakIsRUFBMkIsVUFBM0IsRUFBdUNvRSxLQUF2QztBQUNILEdBSEQ7QUFJSDs7QUFFRDdDLE9BQU8sQ0FBQ0MsR0FBUixFQUNBO0FBQ0s7O3dDQUZMO0FBT0EyRixrQkFBa0I7QUFDbEJTLGtCQUFrQjs7QUFFbEIsU0FBU0MsU0FBVCxHQUFzQjtBQUFFO0FBRXBCO0FBQ0EsTUFBSTlDLEtBQUssR0FBR2pFLE1BQU0sQ0FBQ2lFLEtBQVAsQ0FBYWdDLElBQWIsR0FBb0JFLEtBQXBCLEVBQVo7QUFDQTFGLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLGNBQVosRUFBNEJ1RCxLQUE1QjtBQUNIOztBQUVELFNBQVMrQyxhQUFULEdBQTBCO0FBQUU7QUFFeEI7QUFDQXZHLFNBQU8sQ0FBQ0MsR0FBUixDQUFZLGtCQUFaLEVBQWdDc0YsZUFBZSxFQUEvQztBQUNIOztBQUVELFNBQVNpQixXQUFULENBQXNCVCxJQUF0QixFQUE0QjtBQUFFO0FBRTFCO0FBQ0EsTUFBSSxDQUFDQSxJQUFMLEVBQVc7QUFBRTtBQUFTOztBQUV0QixNQUFJbEQsS0FBSyxHQUFHa0QsSUFBWjs7QUFDQSxNQUFJVSxNQUFNLENBQUNDLFNBQVAsQ0FBaUI1SSxRQUFqQixDQUEwQnFFLElBQTFCLENBQStCNEQsSUFBL0IsTUFBeUMsaUJBQTdDLEVBQWlFO0FBQzdEbEQsU0FBSyxHQUFHLENBQUNrRCxJQUFELENBQVI7QUFDSDs7QUFDRCxNQUFJdkMsS0FBSyxHQUFHakUsTUFBTSxDQUFDaUUsS0FBUCxDQUFhZ0MsSUFBYixHQUFvQkUsS0FBcEIsRUFBWjtBQUNBM0QsT0FBSyxDQUFDdUQsb0JBQU4sQ0FBMkI5QixLQUEzQixFQUFrQ1gsS0FBbEM7O0FBQ0EvRCxHQUFDLENBQUNxRyxJQUFGLENBQU90QyxLQUFQLEVBQWMsVUFBVWtELElBQVYsRUFBZ0I7QUFDMUJoRSxTQUFLLENBQUM0RSxVQUFOLENBQWlCWixJQUFqQjtBQUNILEdBRkQ7QUFHSDs7QUFFRCxTQUFTYSxVQUFULENBQW9CQyxXQUFwQixFQUFpQztBQUFFO0FBRS9CO0FBQ0EsTUFBSWhFLEtBQUssR0FBR2QsS0FBSyxDQUFDK0QsV0FBTixHQUFvQkosS0FBcEIsRUFBWjs7QUFDQSxNQUFJb0IsU0FBUyxHQUFHaEksQ0FBQyxDQUFDMEcsSUFBRixDQUFPM0MsS0FBUCxFQUFjLFVBQVVrRCxJQUFWLEVBQWdCO0FBQzFDLFdBQU9BLElBQUksQ0FBQ0MsSUFBTCxLQUFjYSxXQUFyQjtBQUNILEdBRmUsQ0FBaEI7O0FBR0EsTUFBSSxDQUFDQyxTQUFMLEVBQWdCO0FBQ1ovRSxTQUFLLENBQUM2RSxVQUFOLENBQWlCQyxXQUFqQjtBQUNIO0FBQ0o7O0FBRUQsU0FBU0UsVUFBVCxDQUFvQnRJLFFBQXBCLEVBQThCO0FBQUU7QUFDNUIsTUFBSWlCLElBQUksR0FBR3dFLGdCQUFnQixDQUFDekYsUUFBRCxDQUEzQjtBQUNBYyxRQUFNLENBQUNpRSxLQUFQLENBQWF3RCxNQUFiLENBQW9CdEgsSUFBcEI7QUFDSDs7QUFFRGlDLFFBQVEsQ0FBQ3NGLFlBQVQsQ0FBc0IsVUFBVUMsT0FBVixFQUFtQnhILElBQW5CLEVBQXlCO0FBRTNDO0FBQ0FBLE1BQUksQ0FBQ2pCLFFBQUwsR0FBZ0JpQixJQUFJLENBQUN5SCxNQUFMLENBQVksQ0FBWixFQUFlQyxPQUEvQixDQUgyQyxDQUszQzs7QUFDQSxNQUFJOUYsR0FBRyxHQUFHLGdCQUNONUIsSUFBSSxDQUFDeUgsTUFBTCxDQUFZLENBQVosRUFBZUMsT0FEVCxHQUVOLE1BRk0sR0FHTjlJLFFBQVEsQ0FBQ1IsUUFBVCxFQUhNLEdBSU4sR0FKSjtBQUtBeUYsVUFBUSxDQUFDSyxXQUFELEVBQWN0QyxHQUFkLEVBQW1CQSxHQUFuQixDQUFSLENBWDJDLENBYTNDOztBQUNBLFNBQU81QixJQUFQO0FBQ0gsQ0FmRDtBQWlCQUgsTUFBTSxDQUFDQyxPQUFQLENBQWU7QUFFWDZILDJCQUF5QixFQUFFLFlBQVk7QUFFbkM7QUFDQSxRQUFJM0gsSUFBSSxHQUFHSCxNQUFNLENBQUNHLElBQVAsRUFBWDs7QUFDQSxRQUFJQSxJQUFJLEtBQUssSUFBYixFQUFtQjtBQUNmLGFBQU8sRUFBUDtBQUNILEtBRkQsTUFFTztBQUNILGFBQU9xQyxLQUFLLENBQUNDLGVBQU4sQ0FBc0J0QyxJQUFJLENBQUNOLEdBQTNCLENBQVA7QUFDSDtBQUNKLEdBWFU7QUFhWGtJLGNBQVksRUFBRSxZQUFZO0FBRXRCO0FBQ0EsUUFBSS9ILE1BQU0sQ0FBQ0csSUFBUCxFQUFKLEVBQW1CO0FBQ2YsYUFBT0gsTUFBTSxDQUFDRyxJQUFQLEdBQWNqQixRQUFyQjtBQUNILEtBRkQsTUFFTztBQUNILGFBQU9tQixTQUFQO0FBQ0g7QUFDSjtBQXJCVSxDQUFmO0FBd0JBTCxNQUFNLENBQUNnSSxPQUFQLENBQWdCLE1BQU07QUFFbEIsTUFBSWhJLE1BQU0sQ0FBQzRELFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCUyxHQUEzQixFQUFnQztBQUM1QkEsT0FBRyxHQUFHLElBQU4sQ0FENEIsQ0FDaEI7QUFDZixHQUZELE1BRU87QUFDSEEsT0FBRyxHQUFHLEtBQU47QUFDSDs7QUFFRHZGLFVBQVEsR0FBR2lCLE1BQU0sQ0FBQzRELFFBQVAsQ0FBZ0JDLE1BQWhCLENBQXVCOUUsUUFBbEMsQ0FSa0IsQ0FVbEI7O0FBQ0EsTUFBSWtKLEdBQUcsR0FBRyxLQUFWLENBWGtCLENBWWxCOztBQUVBQyxlQUFhLENBQUNDLE9BQWQsQ0FBc0JDLGlCQUF0QixDQUF3Q0gsR0FBeEMsRUFka0IsQ0FnQmxCOztBQUNBQyxlQUFhLENBQUNDLE9BQWQsQ0FBc0JFLFNBQXRCLEdBakJrQixDQW1CbEI7QUFDQTtBQUVBOztBQUNBaEUsYUFBVyxHQUFHckUsTUFBTSxDQUFDNEQsUUFBUCxDQUFnQkMsTUFBaEIsQ0FBdUJRLFdBQXJDO0FBRUFqQyxVQUFRLENBQUNrRyxjQUFULENBQXdCQyxJQUF4QixHQUErQmxFLFdBQS9CO0FBQ0FqQyxVQUFRLENBQUNrRyxjQUFULENBQXdCRSxRQUF4QixHQUFtQyxtQkFBbkM7QUFFQWpFLE1BQUksR0FBR2tFLEdBQUcsQ0FBQ0MsT0FBSixDQUFZLGVBQVosRUFBNkJuRSxJQUFwQztBQUNBb0UsU0FBTyxHQUFHRixHQUFHLENBQUNDLE9BQUosQ0FBWSxTQUFaLENBQVY7QUFFQTVFLGFBQVc7QUFDZCxDQWhDRCxFOzs7Ozs7Ozs7OztBQ2xUQTtBQUVBO0FBQ0E7QUFFQSxTQUFTOEUsWUFBVCxHQUF5QjtBQUFFO0FBRXZCLE1BQUlDLFFBQVEsR0FBRyxDQUFmLENBRnFCLENBSXJCOztBQUNBLE1BQUlDLEtBQUssR0FBRzlJLE1BQU0sQ0FBQ2lFLEtBQVAsQ0FBYXdELE1BQWIsQ0FBb0IsRUFBcEIsQ0FBWixDQUxxQixDQUtnQjtBQUNyQztBQUVBOztBQUNBLE1BQUl4RCxLQUFLLEdBQUdqRSxNQUFNLENBQUNpRSxLQUFQLENBQWFnQyxJQUFiLENBQWtCLEVBQWxCLEVBQXNCRSxLQUF0QixFQUFaOztBQUNBLE1BQUlsQyxLQUFLLENBQUNWLE1BQU4sR0FBZSxDQUFuQixFQUFzQjtBQUNsQjlDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHFDQUFaO0FBQ0FtSSxZQUFRLElBQUksQ0FBWjtBQUNILEdBYm9CLENBZ0JyQjs7O0FBQ0EsTUFBSXZGLEtBQUssR0FBR2QsS0FBSyxDQUFDK0QsV0FBTixHQUFvQkosS0FBcEIsRUFBWjtBQUNBMkMsT0FBSyxHQUFHeEYsS0FBSyxDQUFDQyxNQUFkOztBQUNBaEUsR0FBQyxDQUFDcUcsSUFBRixDQUFPdEMsS0FBUCxFQUFjLFVBQVVrRCxJQUFWLEVBQWdCO0FBQzFCaEUsU0FBSyxDQUFDNEUsVUFBTixDQUFpQlosSUFBSSxDQUFDQyxJQUF0QjtBQUNILEdBRkQsRUFuQnFCLENBc0JyQjtBQUVBOzs7QUFDQXhDLE9BQUssR0FBRyxDQUNKO0FBQ0kvRSxZQUFRLEVBQUUsZ0JBRGQ7QUFFSTBJLFVBQU0sRUFBRSxDQUNKO0FBQUNDLGFBQU8sRUFBRTtBQUFWLEtBREk7QUFGWixHQURJLEVBT0o7QUFDSTNJLFlBQVEsRUFBRSxnQkFEZDtBQUVJMEksVUFBTSxFQUFFLENBQ0o7QUFBQ0MsYUFBTyxFQUFFO0FBQVYsS0FESTtBQUZaLEdBUEksRUFhSjtBQUNJM0ksWUFBUSxFQUFFLFdBRGQ7QUFFSTBJLFVBQU0sRUFBRSxDQUNKO0FBQUNDLGFBQU8sRUFBRTtBQUFWLEtBREk7QUFGWixHQWJJLENBQVI7QUFvQkEsTUFBSWtCLEdBQUcsR0FBRyxFQUFWO0FBQUEsTUFDSUMsQ0FBQyxHQUFHLENBRFI7O0FBRUEsT0FBSyxJQUFJN0ksSUFBVCxJQUFpQjhELEtBQWpCLEVBQXdCO0FBQ3BCOEUsT0FBRyxDQUFDQyxDQUFELENBQUgsR0FBU2hKLE1BQU0sQ0FBQ2lFLEtBQVAsQ0FBYWdGLE1BQWIsQ0FBb0I5SSxJQUFwQixDQUFUO0FBQ0FNLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHVCQUFaLEVBQXFDcUksR0FBRyxDQUFDQyxDQUFELENBQXhDLEVBRm9CLENBR3BCOztBQUNBQSxLQUFDLElBQUksQ0FBTDtBQUNIOztBQUNEdkksU0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWixFQUFvQnFJLEdBQXBCLEVBckRxQixDQXVEckI7O0FBQ0EsTUFBSUcsVUFBVSxHQUFHbEosTUFBTSxDQUFDaUUsS0FBUCxDQUFhZ0MsSUFBYixHQUFvQkUsS0FBcEIsRUFBakI7O0FBQ0EsTUFBSStDLFVBQVUsQ0FBQzNGLE1BQVgsS0FBc0IsQ0FBMUIsRUFBNkI7QUFDekI5QyxXQUFPLENBQUNDLEdBQVIsQ0FBWSxxQ0FBWjtBQUNBbUksWUFBUSxJQUFJLENBQVo7QUFDSDs7QUFDRHRKLEdBQUMsQ0FBQ3FHLElBQUYsQ0FBT3NELFVBQVAsRUFBbUIsVUFBVS9JLElBQVYsRUFBZ0I2SSxDQUFoQixFQUFtQjtBQUNsQyxRQUFJN0ksSUFBSSxDQUFDTixHQUFMLEtBQWFrSixHQUFHLENBQUNDLENBQUQsQ0FBcEIsRUFBeUI7QUFDckJ2SSxhQUFPLENBQUNDLEdBQVIsQ0FBWSx5QkFBWixFQUF1Q3VELEtBQUssQ0FBQytFLENBQUQsQ0FBTCxDQUFTOUosUUFBaEQ7QUFDQTJKLGNBQVEsSUFBSSxDQUFaO0FBQ0g7QUFDSixHQUxELEVBN0RxQixDQW9FckI7OztBQUNBckcsT0FBSyxDQUFDNkUsVUFBTixDQUFpQixRQUFqQixFQXJFcUIsQ0F1RXJCOztBQUNBL0QsT0FBSyxHQUFHZCxLQUFLLENBQUMrRCxXQUFOLEdBQXFCSixLQUFyQixFQUFSOztBQUNBLE1BQUlnRCxLQUFLLEdBQUc1SixDQUFDLENBQUMwRyxJQUFGLENBQU8zQyxLQUFQLEVBQWMsVUFBVWtELElBQVYsRUFBZ0I7QUFDdEMsV0FBT0EsSUFBSSxDQUFDQyxJQUFMLEtBQWMsUUFBckI7QUFDSCxHQUZXLENBQVo7O0FBR0EsTUFBSSxDQUFDMEMsS0FBTCxFQUFZO0FBQ1IxSSxXQUFPLENBQUNDLEdBQVIsQ0FBWSxxQ0FBWjtBQUNBbUksWUFBUSxJQUFJLENBQVo7QUFDSCxHQS9Fb0IsQ0FpRnJCOzs7QUFDQXJHLE9BQUssQ0FBQ3VCLGVBQU4sQ0FBc0JtRixVQUFVLENBQUMsQ0FBRCxDQUFoQyxFQUFxQyxZQUFyQztBQUNBMUcsT0FBSyxDQUFDdUIsZUFBTixDQUFzQixDQUFDbUYsVUFBVSxDQUFDLENBQUQsQ0FBWCxFQUFnQkEsVUFBVSxDQUFDLENBQUQsQ0FBMUIsQ0FBdEIsRUFBc0QsTUFBdEQ7QUFDQTFHLE9BQUssQ0FBQ3VCLGVBQU4sQ0FBc0JtRixVQUFVLENBQUMsQ0FBRCxDQUFoQyxFQUFxQzFHLEtBQUssQ0FBQzRHLFlBQTNDLEVBcEZxQixDQXNGckI7O0FBQ0EsTUFBSUMsVUFBVSxHQUFHN0csS0FBSyxDQUFDK0QsV0FBTixHQUFvQkosS0FBcEIsRUFBakI7QUFDQTdDLE9BQUssR0FBRyxDQUFDLFlBQUQsRUFBZSxNQUFmLEVBQXVCZCxLQUFLLENBQUM0RyxZQUE3QixDQUFSLEVBQ0E3SixDQUFDLENBQUNxRyxJQUFGLENBQU90QyxLQUFQLEVBQWMsVUFBU2tELElBQVQsRUFBZTtBQUN6QixRQUFJMkMsS0FBSyxHQUFHNUosQ0FBQyxDQUFDMEcsSUFBRixDQUFPb0QsVUFBUCxFQUFtQixVQUFVQyxLQUFWLEVBQWlCO0FBQzVDLGFBQU9BLEtBQUssQ0FBQzdDLElBQU4sS0FBZUQsSUFBdEI7QUFDSCxLQUZXLENBQVo7O0FBR0EsUUFBSSxDQUFDMkMsS0FBTCxFQUFZO0FBQ1IxSSxhQUFPLENBQUNDLEdBQVIsQ0FBWSwwQkFBWixFQUF3QzhGLElBQXhDO0FBQ0FxQyxjQUFRLElBQUksQ0FBWjtBQUNIO0FBQ0osR0FSRCxDQURBLENBeEZxQixDQW1HckI7QUFDQTs7QUFDQSxNQUFJLENBQUNyRyxLQUFLLENBQUMrRyxZQUFOLENBQW1CTCxVQUFVLENBQUMsQ0FBRCxDQUE3QixFQUFrQzVGLEtBQUssQ0FBQyxDQUFELENBQXZDLENBQUwsRUFBa0Q7QUFDOUM3QyxXQUFPLENBQUNDLEdBQVIsQ0FBWSw0QkFBWixFQUEwQ3dJLFVBQVUsQ0FBQyxDQUFELENBQVYsQ0FBY2hLLFFBQXhELEVBQWtFb0UsS0FBSyxDQUFDLENBQUQsQ0FBdkU7QUFDQXVGLFlBQVEsSUFBSSxDQUFaO0FBQ0g7O0FBQ0QsTUFBSSxDQUFDckcsS0FBSyxDQUFDK0csWUFBTixDQUFtQkwsVUFBVSxDQUFDLENBQUQsQ0FBN0IsRUFBa0M1RixLQUFLLENBQUMsQ0FBRCxDQUF2QyxDQUFMLEVBQWtEO0FBQzlDN0MsV0FBTyxDQUFDQyxHQUFSLENBQVksNEJBQVosRUFBMEN3SSxVQUFVLENBQUMsQ0FBRCxDQUFWLENBQWNoSyxRQUF4RCxFQUFrRW9FLEtBQUssQ0FBQyxDQUFELENBQXZFO0FBQ0F1RixZQUFRLElBQUksQ0FBWjtBQUNIOztBQUNELE1BQUksQ0FBQ3JHLEtBQUssQ0FBQytHLFlBQU4sQ0FBbUJMLFVBQVUsQ0FBQyxDQUFELENBQTdCLEVBQWtDNUYsS0FBSyxDQUFDLENBQUQsQ0FBdkMsQ0FBTCxFQUFrRDtBQUM5QzdDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLDRCQUFaLEVBQTBDd0ksVUFBVSxDQUFDLENBQUQsQ0FBVixDQUFjaEssUUFBeEQsRUFBa0VvRSxLQUFLLENBQUMsQ0FBRCxDQUF2RTtBQUNBdUYsWUFBUSxJQUFJLENBQVo7QUFDSDs7QUFDRCxNQUFJLENBQUNyRyxLQUFLLENBQUMrRyxZQUFOLENBQW1CTCxVQUFVLENBQUMsQ0FBRCxDQUE3QixFQUFrQzVGLEtBQUssQ0FBQyxDQUFELENBQXZDLENBQUwsRUFBa0Q7QUFDOUM3QyxXQUFPLENBQUNDLEdBQVIsQ0FBWSw0QkFBWixFQUEwQ3dJLFVBQVUsQ0FBQyxDQUFELENBQVYsQ0FBY2hLLFFBQXhELEVBQWtFb0UsS0FBSyxDQUFDLENBQUQsQ0FBdkU7QUFDQXVGLFlBQVEsSUFBSSxDQUFaO0FBQ0gsR0FwSG9CLENBc0hyQjs7O0FBQ0EsTUFBSVcsU0FBUyxHQUFHaEgsS0FBSyxDQUFDQyxlQUFOLENBQXNCeUcsVUFBVSxDQUFDLENBQUQsQ0FBVixDQUFjckosR0FBcEMsQ0FBaEI7O0FBQ0EsTUFBSTJKLFNBQVMsQ0FBQ2pHLE1BQVYsS0FBcUIsQ0FBekIsRUFBNEI7QUFDeEI5QyxXQUFPLENBQUNDLEdBQVIsQ0FBWSx1Q0FBWixFQUFxRHdJLFVBQVUsQ0FBQyxDQUFELENBQVYsQ0FBY2hLLFFBQW5FO0FBQ0EySixZQUFRLElBQUksQ0FBWjtBQUNIOztBQUNEVyxXQUFTLEdBQUdoSCxLQUFLLENBQUNDLGVBQU4sQ0FBc0J5RyxVQUFVLENBQUMsQ0FBRCxDQUFWLENBQWNySixHQUFwQyxDQUFaOztBQUNBLE1BQUkySixTQUFTLENBQUNqRyxNQUFWLEtBQXFCLENBQXpCLEVBQTRCO0FBQ3hCOUMsV0FBTyxDQUFDQyxHQUFSLENBQVksdUNBQVosRUFBcUR3SSxVQUFVLENBQUMsQ0FBRCxDQUFWLENBQWNoSyxRQUFuRTtBQUNBMkosWUFBUSxJQUFJLENBQVo7QUFDSDs7QUFDRFcsV0FBUyxHQUFHaEgsS0FBSyxDQUFDQyxlQUFOLENBQXNCeUcsVUFBVSxDQUFDLENBQUQsQ0FBVixDQUFjckosR0FBcEMsQ0FBWjs7QUFDQSxNQUFJMkosU0FBUyxDQUFDakcsTUFBVixLQUFxQixDQUF6QixFQUE0QjtBQUN4QjlDLFdBQU8sQ0FBQ0MsR0FBUixDQUFZLHVDQUFaLEVBQXFEd0ksVUFBVSxDQUFDLENBQUQsQ0FBVixDQUFjaEssUUFBbkU7QUFDQTJKLFlBQVEsSUFBSSxDQUFaO0FBQ0g7O0FBRUQsTUFBSUEsUUFBUSxHQUFHLENBQWYsRUFBa0JwSSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxpQ0FBWjtBQUNyQixDLENBR0Q7QUFFQTtBQUVBO0FBRUE7QUFDQTs7QUFFQTs7Ozs7O0FBTUEiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIGJvb2ttYXJrLmpzXG4vLyBCb29rbWFyayBzZXJ2ZXIgbWV0aG9kcy5cblxuaW1wb3J0IENyeXB0b0pTIGZyb20gJ2NyeXB0by1qcydcblxudmFyIEJvb2ttYXJrcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdib29rbWFya3MnKTtcblxuZnVuY3Rpb24gaHVtYW5Ub2RheSAoKSB7XG4gICAgdmFyIGRhdGUgPSBuZXcgRGF0ZSgpLFxuICAgICAgICBpbnRNb250aCA9IHBhcnNlSW50KGRhdGUuZ2V0TW9udGgoKSkgKyAxLFxuICAgICAgICBzdHJNb250aCA9IChpbnRNb250aCA8IDEwKSA/XG4gICAgICAgICAgICAnMCcgKyBpbnRNb250aC50b1N0cmluZygpIDogaW50TW9udGgudG9TdHJpbmcoKTtcbiAgICByZXR1cm4gZGF0ZS5nZXRGdWxsWWVhcigpICsgJy0nICsgc3RyTW9udGggKyAnLScgKyBkYXRlLmdldERhdGUoKTtcbn1cblxuZnVuY3Rpb24gY3JlYXRlSWQgKGpzb25TdGF0ZSkge1xuXG4gICAgLy8gR2VuZXJhdGUgYSBib29rbWFyayBJRCBhbmQgVVJMLlxuICAgIHZhciBpZCA9IENyeXB0b0pTLlNIQTI1Nihqc29uU3RhdGUpLnRvU3RyaW5nKCk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgaWQ6IGlkLFxuICAgICAgICB1cmw6IFVSTF9CQVNFICsgJy8/Ym9va21hcms9JyArIGlkLFxuICAgIH07XG59XG5cbmV4cG9ydHMuY3JlYXRlID0gZnVuY3Rpb24gKGpzb25TdGF0ZSwgdXNlcm5hbWUpIHtcblxuICAgIC8vIENyZWF0ZSBvciB1cGRhdGUgYSBib29rbWFyay5cbiAgICB2YXIga2V5ID0gY3JlYXRlSWQoanNvblN0YXRlKSxcbiAgICAgICAgZGJVc2VybmFtZSA9IHVzZXJuYW1lLFxuICAgICAgICBib29rbWFyayA9IEJvb2ttYXJrcy5maW5kT25lKGtleS5pZC50b1N0cmluZygpKTtcbiAgICBcbiAgICAvLyBJZiB0aGlzIGJvb2ttYXJrIGFscmVhZHkgZXhpc3RzLCB1cGRhdGUgdGhlIHVzZXIgbGlzdC5cbiAgICBpZiAoYm9va21hcmspIHtcblxuICAgICAgICAvLyBDb252ZXJ0IHRoZSBkYiB1c2VybmFtZSBhbmQgdGhlIGdpdmVuIHVzZXJuYW1lIHRvIGEgc2luZ2xlIGFycmF5XG4gICAgICAgIC8vIG9mIHVuaXF1ZSBlbGVtZW50cy5cbiAgICAgICAgZGJVc2VybmFtZSA9IF8udW5pcShbXS5jb25jYXQoYm9va21hcmsudXNlcm5hbWUsIHVzZXJuYW1lKVxuICAgICAgICAgICAgLmZpbHRlcihCb29sZWFuKSk7XG4gICAgfVxuXG4gICAgLy8gSW5zZXJ0L3VwZGF0ZSB0aGUgc3RhdGUgaW50byB0aGUgYm9va21hcmsgY29sbGVjdGlvbi5cbiAgICBCb29rbWFya3MudXBzZXJ0KHsgX2lkOiBrZXkuaWQgfSxcbiAgICAgICAgeyRzZXQ6IHtcbiAgICAgICAgICAgIGpzb25TdGF0ZToganNvblN0YXRlLFxuICAgICAgICAgICAgdXNlcm5hbWU6IGRiVXNlcm5hbWUsXG4gICAgICAgICAgICBsYXN0QWNjZXNzOiBodW1hblRvZGF5KCksXG4gICAgICAgIH19LFxuICAgICk7XG4gICAgXG4gICAgcmV0dXJuIHsgYm9va21hcms6IGtleS51cmwgfTtcbn07XG5cbk1ldGVvci5tZXRob2RzKHtcbiAgICBmaW5kQm9va21hcms6IGZ1bmN0aW9uIChpZCkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgdmFyIGJvb2ttYXJrID0gQm9va21hcmtzLmZpbmRPbmUoaWQudG9TdHJpbmcoKSksXG4gICAgICAgICAgICAgICAgdXNlciA9IE1ldGVvci51c2VyKCk7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGlmICghYm9va21hcmspIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJ0Jvb2ttYXJrIG5vdCBmb3VuZCc7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIC8vIFRPRE8gdXBkYXRlIHRoZSBsYXN0QWNjZXNzIGRhdGVcbiAgICAgICAgICAgIEJvb2ttYXJrcy51cGRhdGUoaWQsIHtcbiAgICAgICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgICAgICAgIHVzZXJuYW1lOiB1c2VyID8gdXNlci51c2VybmFtZSA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAgICAgbGFzdEFjY2VzczogaHVtYW5Ub2RheSgpLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHJldHVybiBKU09OLnBhcnNlKGJvb2ttYXJrLmpzb25TdGF0ZSk7XG4gICAgICAgICAgICBcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgY29uc29sZS5sb2coJ2ZpbmRCb29rbWFyaygpIGZhaWxlZCB3aXRoOicsIGVycm9yLnRvU3RyaW5nKCkpO1xuICAgICAgICAgICAgY29uc29sZS50cmFjZSgpO1xuICAgICAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcignQ291bGQgbm90IGZpbmQgYm9va21hcmsnLCBlcnJvci50b1N0cmluZygpKTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBjcmVhdGVCb29rbWFyazogZnVuY3Rpb24gKGpzb25TdGF0ZSkge1xuICAgIFxuICAgICAgICAvLyBTYXZlIHN0YXRlIGluIGEgYm9va21hcmssIHJldHVybmluZyB0aGUgVVJMLlxuICAgICAgICB0cnkge1xuICAgICAgICAgICAgdmFyIHVzZXIgPSBNZXRlb3IudXNlcigpLFxuICAgICAgICAgICAgICAgIHJlc3VsdCA9IGV4cG9ydHMuY3JlYXRlKFxuICAgICAgICAgICAgICAgICAgICBqc29uU3RhdGUsIHVzZXIgPyB1c2VyLnVzZXJuYW1lIDogdW5kZWZpbmVkKTtcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQuYm9va21hcms7XG4gICAgICAgICAgICBcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ3NhdmVCb29rbWFyaygpIGZhaWxlZCB3aXRoOicsIGUudG9TdHJpbmcoKSk7XG4gICAgICAgICAgICBjb25zb2xlLnRyYWNlKCk7XG4gICAgICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKCdDb3VsZCBub3QgY3JlYXRlIGJvb2ttYXJrJywgZS50b1N0cmluZygpKTtcbiAgICAgICAgfVxuICAgIH1cbn0pO1xuIiwiXG4vLyBodHRwLmpzXG4vLyBIYW5kbGUgaW5jb21pbmcgSFRUUCByZXF1ZXN0cy5cblxuaW1wb3J0IGJvb2ttYXJrIGZyb20gJy4vYm9va21hcmsnO1xuXG5mdW5jdGlvbiByZXNwb25kIChzdGF0dXNDb2RlLCByZXMsIGRhdGFfaW4pIHtcblxuICAgIC8vIFRoaXMgcmVzcG9uZHMgdG8gYW4gaHR0cCByZXF1ZXN0IGJlZm9yZSBjb252ZXJ0aW5nIGRhdGEgdG8ganNvbi5cbiAgICB2YXIgZGF0YSA9IEpTT04uc3RyaW5naWZ5KGRhdGFfaW4pO1xuICAgIHJlcy5zZXRIZWFkZXIoJ0NvbnRlbnQtVHlwZScsICdhcHBsaWNhdGlvbi9qc29uJyk7XG4gICAgcmVzLndyaXRlSGVhZChzdGF0dXNDb2RlKTtcbiAgICByZXMuZW5kKGRhdGEgKyAnXFxuJyk7XG59XG5cbmZ1bmN0aW9uIHBhc3NQb3N0Q2hlY2tzIChyZXEsIHJlcykge1xuXG4gICAgLy8gRG8gc29tZSBiYXNpYyBjaGVja3Mgb24gdGhlIHJlcXVlc3QgaGVhZGVycyxcbiAgICAvLyByZXR1cm5pbmcgZmFsc2UgaWYgbm90IHBhc3NpbmcuXG5cbiAgICAvLyBPbmx5IFBPU1QgbWV0aG9kcyBhcmUgdW5kZXJzdG9vZFxuICAgIGlmIChyZXEubWV0aG9kICE9PSAnUE9TVCcpIHtcbiAgICAgICAgcmVzcG9uZCg0MDUsIHJlcywgJ09ubHkgdGhlIFBPU1QgbWV0aG9kIGlzIHVuZGVyc3Rvb2QgaGVyZScpO1xuICAgIH1cbiAgICBcbiAgICAvLyBPbmx5IGpzb24gY29udGVudCB0eXBlIGlzIHVuZGVyc3Rvb2RcbiAgICBpZiAocmVxLmhlYWRlcnNbJ2NvbnRlbnQtdHlwZSddICE9PSAnYXBwbGljYXRpb24vanNvbicpIHtcbiAgICAgICAgcmVzcG9uZCg0MDAsIHJlcyxcbiAgICAgICAgICAgICdPbmx5IGNvbnRlbnQtdHlwZSBvZiBhcHBsaWNhdGlvbi9qc29uIGlzIHVuZGVyc3Rvb2QgaGVyZScpO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gcGFyc2VKc29uIChqc29uRGF0YSwgcmVzKSB7XG5cbiAgICAvLyBQYXJzZSB0aGUganNvbiBkYXRhLlxuICAgIGxldCBkYXRhID0gbnVsbFxuICAgIHRyeSB7XG4gICAgICAgIGRhdGEgPSBKU09OLnBhcnNlKGpzb25EYXRhKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHZhciBtc2cgPSAnc2VydmVyIGVycm9yIGRlY29kaW5nIEpTT046ICcgKyBlO1xuICAgICAgICByZXNwb25kKDUwMCwgcmVzLCB7ZXJyb3I6IG1zZyB9KTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICByZXR1cm4gZGF0YVxufVxuXG5hc3luYyBmdW5jdGlvbiB1cGRhdGVCb29rbWFya0RhdGFiYXNlIChqc29uU3RhdGUsIGVtYWlsLCByZXMpIHtcbiAgICB0cnkge1xuICAgICAgICBsZXQgcmVzdWx0ID0gYXdhaXQgYm9va21hcmsuY3JlYXRlKGpzb25TdGF0ZSwgZW1haWwpO1xuICAgICAgICByZXNwb25kKDIwMCwgcmVzLCByZXN1bHQpO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJlc3BvbmQoNTAwLCByZXMsIHsgZXJyb3I6IGVycm9yIH0pO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gY3JlYXRlQm9va21hcmsgKGpzb25EYXRhLCByZXEsIHJlcykge1xuICAgIHZhciBkYXRhID0gcGFyc2VKc29uKGpzb25EYXRhLCByZXMpLFxuICAgICAgICBqc29uU3RhdGUgPSBqc29uRGF0YSxcbiAgICAgICAgZW1haWwgPSBudWxsO1xuXG4gICAgLy8gRXh0cmFjdCB0aGUgZW1haWwgaWYgdGhlcmUgaXMgb25lLlxuICAgIGlmIChkYXRhLmhhc093blByb3BlcnR5KCdlbWFpbCcpKSB7XG4gICAgICAgIGVtYWlsID0gZGF0YS5lbWFpbDtcbiAgICAgICAgZGVsZXRlIGRhdGEuZW1haWw7XG4gICAgICAgIGpzb25TdGF0ZSA9IEpTT04uc3RyaW5naWZ5KGRhdGEpO1xuICAgIH1cblxuICAgIHVwZGF0ZUJvb2ttYXJrRGF0YWJhc2UoanNvblN0YXRlLCBlbWFpbCwgcmVzKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gdXBkYXRlQ29sb3IgKGpzb25EYXRhLCByZXEsIHJlcykge1xuICAgIGxldCBkYXRhID0gcGFyc2VKc29uKGpzb25EYXRhLCByZXMpXG4gICAgdHJ5IHtcbiAgICAgICAgbGV0IHVzZXIgPSBhd2FpdCBBY2NvdW50cy5maW5kVXNlckJ5VXNlcm5hbWUoZGF0YS51c2VyRW1haWwpXG4gICAgICAgIGRhdGEudXNlclJvbGUgPSBSb2xlcy5nZXRSb2xlc0ZvclVzZXIodXNlci5faWQpO1xuICAgICAgICBcbiAgICAgICAgLy8gUmVxdWVzdCBlZGl0IG9mIHRoZSBkYXRhIHNlcnZlci5cbiAgICAgICAgbGV0IHVybCA9IEhVQl9VUkwgKyAnL3VwZGF0ZUNvbG9yJ1xuICAgICAgICBIVFRQLmNhbGwoJ1BPU1QnLCB1cmwsIHtkYXRhOiBkYXRhfSwgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgICAgIGlmIChlcnJvcikge1xuICAgICAgICAgICAgICAgIHJlc3BvbmQoNTAwLCByZXMsIHJlc3VsdC5kYXRhKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgcmVzcG9uZCgyMDAsIHJlcywgcmVzdWx0LmRhdGEpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXNwb25kKDUwMCwgcmVzLCB7IGVycm9yOiBlcnJvciB9KTtcbiAgICB9XG59XG5cbmZ1bmN0aW9uIHJlY2VpdmVQb3N0IChvcGVyYXRpb24sIHJlcSwgcmVzKSB7XG4gICAgXG4gICAgLy8gUmVjZWl2ZSBhIHF1ZXJ5IGZvciBhbiBvcGVyYXRpb24gYW5kIHByb2Nlc3MgaXRcbiAgICBcbiAgICBwYXNzUG9zdENoZWNrcyhyZXEsIHJlcylcbiAgICB2YXIganNvbkRhdGEgPSAnJztcbiAgICBcbiAgICByZXEuc2V0RW5jb2RpbmcoJ3V0ZjgnKTtcbiAgICBcbiAgICAvLyBDb250aW51ZSB0byByZWNlaXZlIGNodW5rcyBvZiB0aGlzIHJlcXVlc3RcbiAgICByZXEub24oJ2RhdGEnLCBmdW5jdGlvbiAoY2h1bmspIHtcbiAgICAgICAganNvbkRhdGEgKz0gY2h1bms7XG4gICAgfSk7XG4gICAgXG4gICAgLy8gUHJvY2VzcyB0aGUgZGF0YSBpbiB0aGlzIHJlcXVlc3RcbiAgICByZXEub24oJ2VuZCcsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaWYgKG9wZXJhdGlvbiA9PT0gJ2NyZWF0ZUJvb2ttYXJrJykge1xuICAgICAgICAgICAgY3JlYXRlQm9va21hcmsoanNvbkRhdGEsIHJlcSwgcmVzKTtcbiAgICAgICAgfSBlbHNlIGlmIChvcGVyYXRpb24gPT09ICd1cGRhdGVDb2xvcicpIHtcbiAgICAgICAgICAgIHVwZGF0ZUNvbG9yKGpzb25EYXRhLCByZXEsIHJlcyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXNwb25kKDUwMCwgcmVzLFxuICAgICAgICAgICAgICAgIHtlcnJvcjogJ25vIGhhbmRsZXIgZm9yIHRoaXMgb3BlcmF0aW9uOiAnICsgb3BlcmF0aW9ufSk7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cblxuZnVuY3Rpb24gZWRpdE1hcEdldCAob3BlcmF0aW9uLCByZXEsIHJlcykge1xuXG4gICAgLy8gRWRpdCBhIG1hcCBvbiB0aGUgZGF0YSBzZXJ2ZXIuXG5cbiAgICAvLyBGaW5kIHRoZSB1c2VybmFtZS5cbiAgICBsZXQgdXJsUGFydHMgPSByZXEudXJsLnNwbGl0KCcvJylcbiAgICBsZXQgdXNlcm5hbWUgPSB1cmxQYXJ0c1t1cmxQYXJ0cy5pbmRleE9mKCdlbWFpbCcpICsgMV1cbiAgICBcbiAgICAvLyBHZXQgdGhlIHVzZXIncyByb2xlcy5cbiAgICBsZXQgdXNlciA9IEFjY291bnRzLmZpbmRVc2VyQnlVc2VybmFtZSh1c2VybmFtZSlcbiAgICBsZXQgcm9sZXMgPSBSb2xlcy5nZXRSb2xlc0ZvclVzZXIodXNlci5faWQpO1xuICAgIFxuICAgIGxldCB1cmwgPSBIVUJfVVJMICsgJy8nICsgb3BlcmF0aW9uICsgcmVxLnVybFxuICAgIGlmIChyb2xlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIHVybCArPSAnL3JvbGUvJyArIHJvbGVzLmpvaW4oJysnKTtcbiAgICB9XG4gICAgXG4gICAgLy8gUmVxdWVzdCBlZGl0IG9mIHRoZSBkYXRhIHNlcnZlci5cbiAgICBIVFRQLmNhbGwoJ0dFVCcsIHVybCwgKGVycm9yLCByZXN1bHQpID0+IHtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICByZXNwb25kKDUwMCwgcmVzLCBlcnJvcik7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXNwb25kKDIwMCwgcmVzLCByZXN1bHQuZGF0YSk7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cblxuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy90ZXN0JywgZnVuY3Rpb24gKHJlcSwgcmVzKSB7XG4gICAgcmVzcG9uZCgyMDAsIHJlcywgJ2p1c3QgdGVzdGluZycpO1xufSk7XG5cbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKCcvcXVlcnkvY3JlYXRlQm9va21hcmsnLCBmdW5jdGlvbiAocmVxLCByZXMpIHtcbiAgICByZWNlaXZlUG9zdCgnY3JlYXRlQm9va21hcmsnLCByZXEsIHJlcyk7XG59KTtcblxuLy8gL2RlbGV0ZU1hcC9tYXBJZC91bml0VGVzdC9ub05laWdoYm9ycy9lbWFpbC9zd2F0QHNvZS51Y3NjLmVkdVxuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy9kZWxldGVNYXAnLCBmdW5jdGlvbiAocmVxLCByZXMpIHtcbiAgICBlZGl0TWFwR2V0KCdkZWxldGVNYXAnLCByZXEsIHJlcylcbn0pO1xuXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL3VwZGF0ZUNvbG9yJywgZnVuY3Rpb24gKHJlcSwgcmVzKSB7XG4gICAgcmVjZWl2ZVBvc3QoJ3VwZGF0ZUNvbG9yJywgcmVxLCByZXMpXG59KTtcblxuSFVCX1VSTCA9IE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuSFVCX1VSTDtcbiIsIlxuLy8gc2VjdXJlLmpzXG5cbi8vIFRoaXMgZmlsZSBjb250YWlucyBhbGwgdGhlIG1ldGVvciBzZXJ2ZXIgY29kZSByZWxhdGVkIHRvIHNlY3VyaXR5OlxuLy8gbG9naW5zLCBhc3NvY2lhdGluZyB1c2VycyB3aXRoIHJvbGVzLCBhdXRob3JpemF0aW9uLi4uXG5cbmZ1bmN0aW9uIHVzZXJBY3Rpb25zICgpIHtcblxuICAgIC8vY3JlYXRlUm9sZSgnQ0lSTScpO1xuICAgIC8vcmVtb3ZlUm9sZXMoWydQYW5jYW4xMiddKTtcbiAgICAvL3JlbW92ZVVzZXJzRnJvbVJvbGVzKFsnanN0dWFydEB1Y3NjLmVkdSddLCBbJ2RldicsICdQYW5jYW4xMiddKTtcbiAgICAvL3Nob3dVc2VybmFtZXMoKTtcbiAgICBhZGRVc2Vyc1RvUm9sZXMgKFsna2NoYW1iZTJAdWNzYy5lZHUnXSAsIFsnQ0tDQyddKTtcbiAgICAvL3JlbW92ZVVzZXIoJ3N3YXRAdWNzYy5lZHUnKTtcbiAgICAvKlxuICAgIHZhciB1c2VycyA9IFtcbiAgICAgICAge2VtYWlsOiAna2NoYW1iZTJAdWNzYy5lZHUnLCByb2xlczogWydDS0NDJ119LFxuICAgIF07XG4gICAgY3JlYXRlVXNlcnModXNlcnMpO1xuICAgICovXG59XG5cbmZ1bmN0aW9uIHNlbmRNYWlsICh1c2Vycywgc3ViamVjdCwgbXNnLCBjYWxsYmFjaykge1xuXG4gICAgLy8gU2VuZCBtYWlsIHRvIHVzZXIocykgd2l0aCB0aGUgZ2l2ZW4gc3ViamVjdCBhbmQgbWVzc2FnZS5cbiAgICAvLyBUaGlzIGNhbiB0YWtlIG9uZSB1c2VybmFtZSBvciBhbiBhcnJheSBvZiB1c2VybmFtZXMuXG4gICAgdmFyIGNvbW1hbmQgPVxuICAgICAgICAnZWNobyBcIidcbiAgICAgICAgKyBtc2dcbiAgICAgICAgKyAnXCIgfCAnXG4gICAgICAgICsgJ21haWwgLXMgXCInXG4gICAgICAgICsgc3ViamVjdFxuICAgICAgICArICdcIiAtUyBmcm9tPVwiJ1xuICAgICAgICArIEFETUlOX0VNQUlMXG4gICAgICAgICsgJ1wiICdcbiAgICAgICAgKyB1c2Vycy50b1N0cmluZygpO1xuICAgIFxuICAgIGlmIChERVYpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ3NlbmRNYWlsKCk6JywgY29tbWFuZCk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgXG4gICAgLyogZXNsaW50LWRpc2FibGUgbm8tdW51c2VkLXZhcnMgKi9cbiAgICBleGVjKGNvbW1hbmQsIGZ1bmN0aW9uIChlcnJvciwgc3Rkb3V0LCBzdGRlcnIpIHtcbiAgICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgICAgICB2YXIgZXJyTXNnID0gJ0Vycm9yIG9uIHNlbmRNYWlsKCk6ICcgKyBlcnJvcjtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGVyck1zZyk7XG4gICAgICAgICAgICBpZiAoY2FsbGJhY2spIHsgY2FsbGJhY2soZXJyTXNnKTsgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgaWYgKGNhbGxiYWNrKSB7IGNhbGxiYWNrKCk7IH1cbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG5mdW5jdGlvbiB1c2VybmFtZXNUb1VzZXJzICh1c2VybmFtZXNJbikge1xuICAgIHZhciB1c2VybmFtZXMgPSB1c2VybmFtZXNJbjtcbiAgICBpZiAodHlwZW9mIHVzZXJuYW1lcyA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgdXNlcm5hbWVzID0gW3VzZXJuYW1lc0luXTtcbiAgICB9XG4gICAgdmFyIGFycmF5ID0gXy5tYXAodXNlcm5hbWVzLCBmdW5jdGlvbiAodXNlcm5hbWUpIHtcbiAgICAgICAgcmV0dXJuIEFjY291bnRzLmZpbmRVc2VyQnlVc2VybmFtZSh1c2VybmFtZSk7XG4gICAgfSk7XG4gICAgaWYgKHR5cGVvZiB1c2VybmFtZXNJbiA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgcmV0dXJuIGFycmF5WzBdO1xuICAgIH1cbiAgICByZXR1cm4gYXJyYXk7XG59XG5cbmZ1bmN0aW9uIHNlbmRFbnJvbGxtZW50RW1haWwodXNlcm5hbWUpIHtcbiAgICB2YXIgdXNlciA9IHVzZXJuYW1lc1RvVXNlcnModXNlcm5hbWUpO1xuICAgIHZhciB0b2tlbiA9IFJhbmRvbS5zZWNyZXQoKTtcbiAgICB2YXIgZGF0ZSA9IG5ldyBEYXRlKCk7XG4gICAgdmFyIHRva2VuUmVjb3JkID0ge1xuICAgICAgICB0b2tlbjogdG9rZW4sXG4gICAgICAgIGVtYWlsOiB1c2VyLnVzZXJuYW1lLFxuICAgICAgICB3aGVuOiBkYXRlXG4gICAgfTtcbiAgICBNZXRlb3IudXNlcnMudXBkYXRlKHVzZXIuX2lkLCB7JHNldDoge1xuICAgICAgICBcInNlcnZpY2VzLnBhc3N3b3JkLnJlc2V0XCI6IHRva2VuUmVjb3JkXG4gICAgfX0pO1xuXG4gICAgLy8gQmVmb3JlIGVtYWlsaW5nLCB1cGRhdGUgdXNlciBvYmplY3Qgd2l0aCBuZXcgdG9rZW5cbiAgICBNZXRlb3IuX2Vuc3VyZSh1c2VyLCAnc2VydmljZXMnLCAncGFzc3dvcmQnKS5yZXNldCA9IHRva2VuUmVjb3JkO1xuICAgIHZhciBlbnJvbGxBY2NvdW50VXJsID0gQWNjb3VudHMudXJscy5lbnJvbGxBY2NvdW50KHRva2VuKTtcblxuICAgIC8qXG4gICAgLy8gQ29ycnVwdGVkIHBhc3N3b3JkcyBtZXNzYWdlOlxuICAgIHZhciBzdWJqZWN0ID0gJ1BsZWFzZSByZXNldCB5b3VyIHBhc3N3b3JkIGF0ICcgK1xuICAgICAgICBVUkxfQkFTRS50b1N0cmluZygpO1xuICAgIHZhciBtc2cgPSAnWW91ciBwYXNzd29yZCBoYXMgYmVlbiBjb3JydXB0ZWQgJyArXG4gICAgICAgICAgICAgICdzbyBwbGVhc2UgcmVzZXQgaXQgYXQgdGhlIGxpbmsgYmVsb3cuICcgK1xuICAgICAgICAgICAgICAnTm90ZSB0aGF0IG5vIG9uZSBvYnRhaW5lZCB5b3VyIHBhc3N3b3JkLCAnICtcbiAgICAgICAgICAgICAgJ3NvIHlvdSBtYXkgdXNlIHRoZSBzYW1lIG9uZSB5b3UgaGFkIHByZXZpb3VzbHkuXFxuXFxuJyArXG4gICAgICAgICAgICAgIGVucm9sbEFjY291bnRVcmwgKyAnXFxuXFxuJyArXG4gICAgICAgICAgICAgICdQbGVhc2UgbGV0IHVzIGtub3cgaWYgeW91IGRvIG5vdCBoYXZlIGFjY2VzcyB0byAnK1xuICAgICAgICAgICAgICAnbWFwcyB0aGF0IHlvdSBjb3VsZCBwcmV2aW91c2x5IHNlZS4gXFxuXFxuJyArXG4gICAgICAgICAgICAgICdUaGFuayB5b3UgYW5kIHNvcnJ5IGZvciBhbnkgaW5jb252ZW5pZW5jZS4nXG4gICAgKi9cbiAgICBcbiAgICB2YXIgc3ViamVjdCA9ICdBbiBhY2NvdW50IGhhcyBiZWVuIGNyZWF0ZWQgZm9yIHlvdSBvbiAnICtcbiAgICAgICAgVVJMX0JBU0UudG9TdHJpbmcoKTtcbiAgICB2YXIgbXNnID0gc3ViamVjdCArICdcXG4nICtcbiAgICAgICAgICAgICAgJ1BsZWFzZSBzZXQgeW91ciBwYXNzd29yZCB3aXRoaW4gb25lIHdlZWsgYXQ6IFxcblxcbicgK1xuICAgICAgICAgICAgICBlbnJvbGxBY2NvdW50VXJsO1xuIFxuICAgIHNlbmRNYWlsKHVzZXJuYW1lLCBzdWJqZWN0LCBtc2cpO1xuICAgIFxuICAgIC8vIEFuZCB0ZWxsIHRoZSBhZG1pblxuICAgIG1zZyA9IFwiJ05ldyB1c2VyIGJ5IGFkbWluOiBcIiArXG4gICAgICAgIHVzZXJuYW1lICtcbiAgICAgICAgJyBhdCAnICtcbiAgICAgICAgVVJMX0JBU0UudG9TdHJpbmcoKSArXG4gICAgICAgICcgd2l0aCByb2xlczogJyArXG4gICAgICAgIHVzZXIucm9sZXM7XG4gICAgc2VuZE1haWwoQURNSU5fRU1BSUwsIG1zZywgbXNnKTtcbn1cblxuZnVuY3Rpb24gY3JlYXRlVXNlcnModXNlcnMpIHsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby11bnVzZWQtdmFyc1xuICAgIF8uZWFjaCh1c2VycywgZnVuY3Rpb24gKHVzZXIpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHZhciBpZCA9IEFjY291bnRzLmNyZWF0ZVVzZXIoe1xuICAgICAgICAgICAgICAgIGVtYWlsOiB1c2VyLmVtYWlsLFxuICAgICAgICAgICAgICAgIHBhc3N3b3JkOiBcImNoYW5nZU1lXCIsXG4gICAgICAgICAgICAgICAgdXNlcm5hbWU6IHVzZXIuZW1haWwsXG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgLy8gQ3JlYXRlIHRoZSB1c2VyIGFuZCBhZGQgdGhlIHJvbGVzIHRvIHRoZSB1c2VyJ3Mgb2JqZWN0XG4gICAgICAgICAgICBpZiAodXNlci5yb2xlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgICAgICAgUm9sZXMuYWRkVXNlcnNUb1JvbGVzKGlkLCB1c2VyLnJvbGVzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHNlbmRFbnJvbGxtZW50RW1haWwodXNlci5lbWFpbCk7XG4gICAgICAgICAgIFxuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgY29uc29sZS5sb2coYGF0dGVtcHRpbmcgdG8gYWRkIHVzZXIgdG8gcm9sZSBzaW5jZSBjcmVhdGVVc2VyXG4gICAgICAgICAgICAgICAgZmFpbGVkOmAgLCB1c2VyLmVtYWlsLCBlcnJvcik7XG4gICAgICAgICAgICBhZGRVc2Vyc1RvUm9sZXMoW3VzZXIuZW1haWxdICwgdXNlci5yb2xlcyk7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cblxuZnVuY3Rpb24gYWRkVXNlcnNUb1JvbGVzICh1c2VybmFtZXMsIHJvbGVzKSB7XG5cbiAgICAvLyBBZGQgdXNlcnMgdG8gcm9sZXNcbiAgICAvLyBVc2VycyBtdXN0IGV4aXN0XG4gICAgLy8gTm9uLWV4aXN0YW50IHJvbGVzIHdpbGwgYmUgY3JlYXRlZFxuICAgIC8vIER1cGxpY2F0ZSByb2xlcyB3aWxsIGJlIG5vdCBhZGRlZFxuICAgIHZhciB1c2VycyA9IHVzZXJuYW1lc1RvVXNlcnModXNlcm5hbWVzKTtcbiAgICBpZiAodXNlcnMpIHtcbiAgICAgICAgY29uc29sZS5sb2coXG4gICAgICAgICAgICAnYWRkaW5nIHVzZXJzIHRvIHJvbGVzLiB1c2VybmFtZXM6ICcsIHVzZXJzLCAncm9sZXM6Jywgcm9sZXMpXG4gICAgICAgIFJvbGVzLmFkZFVzZXJzVG9Sb2xlcyh1c2Vycywgcm9sZXMpO1xuICAgIH1cbn1cblxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVudXNlZC12YXJzXG5mdW5jdGlvbiByZW1vdmVVc2Vyc0Zyb21Sb2xlcyh1c2VybmFtZXMsIHJvbGVzKSB7XG5cbiAgICB2YXIgdXNlcnMgPSB1c2VybmFtZXNUb1VzZXJzKHVzZXJuYW1lcyk7XG4gICAgUm9sZXMucmVtb3ZlVXNlcnNGcm9tUm9sZXModXNlcnMsIHJvbGVzKTtcbn1cblxuZnVuY3Rpb24gZ2V0QWxsVXNlcm5hbWVzICgpIHtcblxuICAgIC8vIEZpbmQgYWxsIG9mIHRoZSB1c2VybmFtZXNcbiAgICB2YXIgdXNlcnMgPSBNZXRlb3IudXNlcnMuZmluZCh7fSwge2ZpZWxkczoge3VzZXJuYW1lOiAxLCBfaWQ6IDB9fSkuZmV0Y2goKTtcbiAgICByZXR1cm4gXy5tYXAodXNlcnMsIGZ1bmN0aW9uICh1c2VyKSB7XG4gICAgICAgIHJldHVybiB1c2VyLnVzZXJuYW1lO1xuICAgIH0pO1xufVxuXG5mdW5jdGlvbiBnZXRBbGxVc2VycyAoKSB7XG5cbiAgICAvLyBGaW5kIGFsbCBvZiB0aGUgdXNlcnMuXG4gICAgcmV0dXJuIE1ldGVvci51c2Vycy5maW5kKHt9LCB7ZmllbGRzOiB7dXNlcm5hbWU6IDEsIF9pZDogMX19KS5mZXRjaCgpO1xufVxuXG5mdW5jdGlvbiBzaG93Um9sZXNXaXRoVXNlcnMoKSB7XG5cbiAgICAvLyBTaG93IGFsbCByb2xlcyB3aXRoIHVzZXJzIGluIGVhY2guXG4gICAgdmFyIHJvbGVPYmpzID0gUm9sZXMuZ2V0QWxsUm9sZXMoKS5mZXRjaCgpO1xuICAgIHZhciByb2xlcyA9IF8ubWFwKHJvbGVPYmpzLCBmdW5jdGlvbihyb2xlKSB7XG4gICAgICAgIHJldHVybiByb2xlLm5hbWU7XG4gICAgfSk7XG4gICAgXG4gICAgY29uc29sZS5sb2coJ1xcblJvbGVzIHdpdGggdXNlcnM6IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuICAgIHZhciBub1JvbGVVc2VycyA9IGdldEFsbFVzZXJuYW1lcygpO1xuICAgIF8uZWFjaChyb2xlcywgZnVuY3Rpb24gKHJvbGUpIHtcbiAgICAgICAgdmFyIHVzZXJzID0gUm9sZXMuZ2V0VXNlcnNJblJvbGUocm9sZSkuZmV0Y2goKTtcbiAgICAgICAgdmFyIHVzZXJuYW1lcyA9IF8ubWFwKHVzZXJzLCBmdW5jdGlvbiAodXNlcikge1xuICAgICAgICAgICAgdmFyIGluZGV4ID0gbm9Sb2xlVXNlcnMuaW5kZXhPZih1c2VyLnVzZXJuYW1lKTtcbiAgICAgICAgICAgIGlmIChpbmRleCA+IC0xKSB7XG4gICAgICAgICAgICAgICAgbm9Sb2xlVXNlcnMuc3BsaWNlKGluZGV4LCAxKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB1c2VyLnVzZXJuYW1lO1xuICAgICAgICB9KTtcbiAgICAgICAgY29uc29sZS5sb2cocm9sZSwgJzogVXNlcnM6JywgdXNlcm5hbWVzKTtcbiAgICB9KTtcbiAgICBcbn1cblxuZnVuY3Rpb24gc2hvd1VzZXJzV2l0aFJvbGVzICgpIHtcblxuICAgIC8vIFByaW50IGZvciBlYWNoIHVzZXIgd2l0aCBoZXIgcm9sZXMuXG4gICAgY29uc29sZS5sb2coJ1xcblVzZXJzIHdpdGggcm9sZXM6IC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuICAgIF8uZWFjaChnZXRBbGxVc2VycygpLCBmdW5jdGlvbiAodXNlcikge1xuICAgICAgICB2YXIgcm9sZXMgPSBSb2xlcy5nZXRSb2xlc0ZvclVzZXIodXNlci5faWQpO1xuICAgICAgICBjb25zb2xlLmxvZyh1c2VyLnVzZXJuYW1lLCAnOiBSb2xlczonLCByb2xlcyk7XG4gICAgfSk7XG59XG5cbmNvbnNvbGUubG9nKFxuLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL1xuICAgIGBcXG5JZ25vcmUgYWJvdmUgd2FybmluZyBhYm91dCBiY3J5cHQuIEl0IGlzIG9ubHkgZm9yXG4gICAgcGFzc3dvcmRzIGFuZCBpcyBsYXJnZS5cbiAgICBXZSdkIHJhdGhlciBoYXZlIGZhc3RlciBsb2FkIHRpbWVzLmBcbik7XG5cbnNob3dSb2xlc1dpdGhVc2VycygpO1xuc2hvd1VzZXJzV2l0aFJvbGVzKCk7XG5cbmZ1bmN0aW9uIHNob3dVc2VycyAoKSB7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tdW51c2VkLXZhcnNcblxuICAgIC8vIFNob3cgYWxsIHVzZXJzIHdpdGggdGhlaXIgcHJvcGVydGllc1xuICAgIHZhciB1c2VycyA9IE1ldGVvci51c2Vycy5maW5kKCkuZmV0Y2goKTtcbiAgICBjb25zb2xlLmxvZygnYWxsIHVzZXJzOlxcbicsIHVzZXJzKTtcbn1cblxuZnVuY3Rpb24gc2hvd1VzZXJuYW1lcyAoKSB7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tdW51c2VkLXZhcnNcblxuICAgIC8vIFNob3cgYWxsIHVzZXJuYW1lc1xuICAgIGNvbnNvbGUubG9nKCdhbGwgdXNlcm5hbWVzOlxcbicsIGdldEFsbFVzZXJuYW1lcygpKTtcbn1cblxuZnVuY3Rpb24gcmVtb3ZlUm9sZXMgKHJvbGUpIHsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby11bnVzZWQtdmFyc1xuXG4gICAgLy8gRHJvcCBhbGwgdXNlcnMgZnJvbSB0aGUgcm9sZXMgYW5kIHJlbW92ZSB0aGUgcm9sZXMuXG4gICAgaWYgKCFyb2xlKSB7IHJldHVybjsgfVxuICAgIFxuICAgIHZhciByb2xlcyA9IHJvbGU7XG4gICAgaWYgKE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChyb2xlKSA9PT0gJ1tvYmplY3QgU3RyaW5nXScgKSB7XG4gICAgICAgIHJvbGVzID0gW3JvbGVdO1xuICAgIH1cbiAgICB2YXIgdXNlcnMgPSBNZXRlb3IudXNlcnMuZmluZCgpLmZldGNoKCk7XG4gICAgUm9sZXMucmVtb3ZlVXNlcnNGcm9tUm9sZXModXNlcnMsIHJvbGVzKTtcbiAgICBfLmVhY2gocm9sZXMsIGZ1bmN0aW9uIChyb2xlKSB7XG4gICAgICAgIFJvbGVzLmRlbGV0ZVJvbGUocm9sZSk7XG4gICAgfSk7XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZVJvbGUobmV3Um9sZU5hbWUpIHsgLy8gZXNsaW50LWRpc2FibGUtbGluZSBuby11bnVzZWQtdmFyc1xuICAgIFxuICAgIC8vIENyZWF0ZSBhIHJvbGUgdW5sZXNzIGl0IGFscmVhZHkgZXhpc3RzXG4gICAgdmFyIHJvbGVzID0gUm9sZXMuZ2V0QWxsUm9sZXMoKS5mZXRjaCgpO1xuICAgIHZhciBmb3VuZFJvbGUgPSBfLmZpbmQocm9sZXMsIGZ1bmN0aW9uIChyb2xlKSB7XG4gICAgICAgIHJldHVybiByb2xlLm5hbWUgPT09IG5ld1JvbGVOYW1lO1xuICAgIH0pO1xuICAgIGlmICghZm91bmRSb2xlKSB7XG4gICAgICAgIFJvbGVzLmNyZWF0ZVJvbGUobmV3Um9sZU5hbWUpO1xuICAgIH1cbn1cblxuZnVuY3Rpb24gcmVtb3ZlVXNlcih1c2VybmFtZSkgeyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXVudXNlZC12YXJzXG4gICAgdmFyIHVzZXIgPSB1c2VybmFtZXNUb1VzZXJzKHVzZXJuYW1lKTtcbiAgICBNZXRlb3IudXNlcnMucmVtb3ZlKHVzZXIpO1xufVxuXG5BY2NvdW50cy5vbkNyZWF0ZVVzZXIoZnVuY3Rpb24gKG9wdGlvbnMsIHVzZXIpIHtcblxuICAgIC8vIEFkZCBhIGZpZWxkIG9mICd1c2VybmFtZScgdGhhdCBtZXRlb3IgcmVjb2duaXplcyBhcyB1bmlxdWVcbiAgICB1c2VyLnVzZXJuYW1lID0gdXNlci5lbWFpbHNbMF0uYWRkcmVzcztcbiAgICBcbiAgICAvLyBTZW5kIHRoZSBhZG1pbiBhbiBlbWFpbC5cbiAgICB2YXIgbXNnID0gXCInTmV3IHVzZXI6IFwiICtcbiAgICAgICAgdXNlci5lbWFpbHNbMF0uYWRkcmVzcyArXG4gICAgICAgICcgYXQgJyArXG4gICAgICAgIFVSTF9CQVNFLnRvU3RyaW5nKCkgK1xuICAgICAgICBcIidcIjtcbiAgICBzZW5kTWFpbChBRE1JTl9FTUFJTCwgbXNnLCBtc2cpO1xuICAgIFxuICAgIC8vIERvbid0IGZvcmdldCB0byByZXR1cm4gdGhlIG5ldyB1c2VyIG9iamVjdC5cbiAgICByZXR1cm4gdXNlcjtcbn0pO1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgICBnZXRVc2VyQXV0aG9yaXphdGlvblJvbGVzOiBmdW5jdGlvbiAoKSB7XG4gICAgXG4gICAgICAgIC8vIEdldCB0aGUgY3VycmVudCB1c2VyJ3MgYXV0aG9yaXphdGlvbiByb2xlcy5cbiAgICAgICAgdmFyIHVzZXIgPSBNZXRlb3IudXNlcigpO1xuICAgICAgICBpZiAodXNlciA9PT0gbnVsbCkge1xuICAgICAgICAgICAgcmV0dXJuIFtdO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmV0dXJuIFJvbGVzLmdldFJvbGVzRm9yVXNlcih1c2VyLl9pZCk7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgZ2V0X3VzZXJuYW1lOiBmdW5jdGlvbiAoKSB7XG4gICAgXG4gICAgICAgIC8vIEdldCB0aGUgdXNlcm5hbWUgb2YgdGhlIGN1cnJlbnQgdXNlclxuICAgICAgICBpZiAoTWV0ZW9yLnVzZXIoKSkge1xuICAgICAgICAgICAgcmV0dXJuIE1ldGVvci51c2VyKCkudXNlcm5hbWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgfSxcbn0pO1xuXG5NZXRlb3Iuc3RhcnR1cCggKCkgPT4ge1xuXG4gICAgaWYgKE1ldGVvci5zZXR0aW5ncy5wdWJsaWMuREVWKSB7XG4gICAgICAgIERFViA9IHRydWU7IC8vZGV2ZWxvcG1lbnQgZnVuY3Rpb25hbGl0eSB3aWxsIGJlIGluY2x1ZGVkXG4gICAgfSBlbHNlIHtcbiAgICAgICAgREVWID0gZmFsc2U7XG4gICAgfVxuXG4gICAgVVJMX0JBU0UgPSBNZXRlb3Iuc2V0dGluZ3MucHVibGljLlVSTF9CQVNFO1xuXG4gICAgLy8gQWxsb3cgY29udGVudCBmcm9tIGFueXdoZXJlXG4gICAgdmFyIGFsbCA9ICcqOionO1xuICAgIC8vdmFyIGtvbG9zc3VzID0gJyoua29sb3NzdXMuc2RzYy5lZHU6Kic7XG5cbiAgICBCcm93c2VyUG9saWN5LmNvbnRlbnQuYWxsb3dPcmlnaW5Gb3JBbGwoYWxsKTtcbiAgICBcbiAgICAvLyBXZSBtdXN0IGFsbG93IHVzZSBvZiBldmlsIGV2YWwgaW4gamF2YXNjcmlwdCBmb3IgZ29vZ2xlIGNoYXJ0cy5cbiAgICBCcm93c2VyUG9saWN5LmNvbnRlbnQuYWxsb3dFdmFsKCk7XG4gICAgICAgIFxuICAgIC8vIEFsbG93IGNvbnRlbnQgc25pZmZpbmcgYnkgZ29vZ2xlIGFuYWx5dGljc1xuICAgIC8vQnJvd3NlclBvbGljeS5jb250ZW50LmFsbG93Q29udGVudFR5cGVTbmlmZmluZygpO1xuXG4gICAgLy8gRnJvbSB0aGUgc2V0dGluZ3MuanNvbiBmaWxlLlxuICAgIEFETUlOX0VNQUlMID0gTWV0ZW9yLnNldHRpbmdzLnB1YmxpYy5BRE1JTl9FTUFJTDtcbiAgICBcbiAgICBBY2NvdW50cy5lbWFpbFRlbXBsYXRlcy5mcm9tID0gQURNSU5fRU1BSUw7XG4gICAgQWNjb3VudHMuZW1haWxUZW1wbGF0ZXMuc2l0ZU5hbWUgPSAndHVtb3JNYXAudWNzYy5lZHUnO1xuXG4gICAgZXhlYyA9IE5wbS5yZXF1aXJlKCdjaGlsZF9wcm9jZXNzJykuZXhlYztcbiAgICBwcm9jZXNzID0gTnBtLnJlcXVpcmUoJ3Byb2Nlc3MnKTtcbiAgICBcbiAgICB1c2VyQWN0aW9ucygpO1xufSk7XG5cbiIsIlxuLy8gc2VjdXJlUm9sZVRlc3RzLmpzXG5cbi8vIE1ldGVvciBzZXJ2ZXIgY29kZSB0byB0ZXN0IHJvbGUgcGFja2FnZSBzZWN1cml0eVxuLy8gTm90ZSB0aGlzIG9ubHkgdGVzdHMgdGhlIFJvbGVzIHBhY2thZ2UgYW5kIG5vdCBvdXIgZnVuY3Rpb25zIGluIHNlY3VyZS5qc1xuXG5mdW5jdGlvbiBydW5Vbml0VGVzdHMgKCkgeyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLXVudXNlZC12YXJzXG5cbiAgICB2YXIgZmFpbHVyZXMgPSAwO1xuXG4gICAgLy8gQ2xlYXIgYWxsIHVzZXJzXG4gICAgdmFyIGNvdW50ID0gTWV0ZW9yLnVzZXJzLnJlbW92ZSh7fSk7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgbm8tdW51c2VkLXZhcnNcbiAgICAvL2NvbnNvbGUubG9nKCdkZWxldGVBbGxVc2VyczogbnVtYmVyIG9mIHVzZXJzIHJlbW92ZWQ6JywgY291bnQpO1xuICAgIFxuICAgIC8vIFZlcmlmeSBhbGwgdXNlcnMgYXJlIHJlbW92ZWRcbiAgICB2YXIgdXNlcnMgPSBNZXRlb3IudXNlcnMuZmluZCh7fSkuZmV0Y2goKTtcbiAgICBpZiAodXNlcnMubGVuZ3RoID4gMCkge1xuICAgICAgICBjb25zb2xlLmxvZygnRkFJTEVEOiBub3QgYWxsIHVzZXJzIHdlcmUgcmVtb3ZlZC4nKTtcbiAgICAgICAgZmFpbHVyZXMgKz0gMTtcbiAgICB9XG4gICAgXG5cbiAgICAvLyBDbGVhciBhbGwgcm9sZXNcbiAgICB2YXIgcm9sZXMgPSBSb2xlcy5nZXRBbGxSb2xlcygpLmZldGNoKCk7XG4gICAgY291bnQgPSByb2xlcy5sZW5ndGg7XG4gICAgXy5lYWNoKHJvbGVzLCBmdW5jdGlvbiAocm9sZSkge1xuICAgICAgICBSb2xlcy5kZWxldGVSb2xlKHJvbGUubmFtZSk7XG4gICAgfSk7XG4gICAgLy9jb25zb2xlLmxvZygnZGVsZXRlQWxsUm9sZXM6IG51bWJlciBvZiByb2xlcyByZW1vdmVkOicsIGNvdW50KTtcblxuICAgIC8vIEFkZCB1c2Vyc1xuICAgIHVzZXJzID0gW1xuICAgICAgICB7XG4gICAgICAgICAgICB1c2VybmFtZTogJ2FEZXZlbG9wZXJAYS5hJyxcbiAgICAgICAgICAgIGVtYWlsczogW1xuICAgICAgICAgICAgICAgIHthZGRyZXNzOiAnYUBhLmEnfSxcbiAgICAgICAgICAgIF1cbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgICAgdXNlcm5hbWU6ICdja2NjTWVtYmVyQGEuYScsXG4gICAgICAgICAgICBlbWFpbHM6IFtcbiAgICAgICAgICAgICAgICB7YWRkcmVzczogJ2JAYS5hJ30sXG4gICAgICAgICAgICBdXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAgIHVzZXJuYW1lOiAnYWRtaW5AYS5hJyxcbiAgICAgICAgICAgIGVtYWlsczogW1xuICAgICAgICAgICAgICAgIHthZGRyZXNzOiAnY0BhLmEnfSxcbiAgICAgICAgICAgIF1cbiAgICAgICAgfSxcbiAgICBdO1xuICAgIHZhciBpZHMgPSBbXSxcbiAgICAgICAgaSA9IDA7XG4gICAgZm9yIChsZXQgdXNlciBpbiB1c2Vycykge1xuICAgICAgICBpZHNbaV0gPSBNZXRlb3IudXNlcnMuaW5zZXJ0KHVzZXIpO1xuICAgICAgICBjb25zb2xlLmxvZygncmMgb24gaW5zZXJ0IG9mIHVzZXI6JywgaWRzW2ldKTtcbiAgICAgICAgLy9mYWlsdXJlcyArPSAxO1xuICAgICAgICBpICs9IDE7XG4gICAgfVxuICAgIGNvbnNvbGUubG9nKCdpZHM6JywgaWRzKTtcblxuICAgIC8vIFZlcmlmeSB1c2VycyBhZGRlZFxuICAgIHZhciB1c2Vyc0FkZGVkID0gTWV0ZW9yLnVzZXJzLmZpbmQoKS5mZXRjaCgpO1xuICAgIGlmICh1c2Vyc0FkZGVkLmxlbmd0aCAhPT0gMykge1xuICAgICAgICBjb25zb2xlLmxvZygnRkFJTEVEOiB1c2VycyBhZGRlZCBjb3VudCBpcyBub3QgMy4nKTtcbiAgICAgICAgZmFpbHVyZXMgKz0gMTtcbiAgICB9XG4gICAgXy5lYWNoKHVzZXJzQWRkZWQsIGZ1bmN0aW9uICh1c2VyLCBpKSB7XG4gICAgICAgIGlmICh1c2VyLl9pZCAhPT0gaWRzW2ldKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZygnRkFJTEVEOiB1c2VyIG5vdCBhZGRlZDonLCB1c2Vyc1tpXS51c2VybmFtZSk7XG4gICAgICAgICAgICBmYWlsdXJlcyArPSAxO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgXG4gICAgLy8gQ3JlYXRlIHRoZSBwdWJsaWMgZ3JvdXBcbiAgICBSb2xlcy5jcmVhdGVSb2xlKCdwdWJsaWMnKTtcbiAgICBcbiAgICAvLyBWZXJpZnkgcm9sZSBhZGRlZFxuICAgIHJvbGVzID0gUm9sZXMuZ2V0QWxsUm9sZXMgKCkuZmV0Y2goKTtcbiAgICB2YXIgZm91bmQgPSBfLmZpbmQocm9sZXMsIGZ1bmN0aW9uIChyb2xlKSB7XG4gICAgICAgIHJldHVybiByb2xlLm5hbWUgPT09ICdwdWJsaWMnO1xuICAgIH0pO1xuICAgIGlmICghZm91bmQpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ0ZBSUxFRDogcHVibGljIHJvbGUgd2FzIG5vdCBjcmVhdGVkJyk7XG4gICAgICAgIGZhaWx1cmVzICs9IDE7XG4gICAgfVxuXG4gICAgLy8gQWRkIHVzZXJzIHRvIHJvbGVzLCBjcmVhdGluZyByb2xlcyBhcyBuZWVkZWQuIHVzZXJzIGFyZSB1c2VyIG9iamVjdHM/XG4gICAgUm9sZXMuYWRkVXNlcnNUb1JvbGVzKHVzZXJzQWRkZWRbMF0sICdhRGV2ZWxvcGVyJyk7XG4gICAgUm9sZXMuYWRkVXNlcnNUb1JvbGVzKFt1c2Vyc0FkZGVkWzBdLCB1c2Vyc0FkZGVkWzFdXSwgJ0NLQ0MnKTtcbiAgICBSb2xlcy5hZGRVc2Vyc1RvUm9sZXModXNlcnNBZGRlZFsyXSwgUm9sZXMuR0xPQkFMX0dST1VQKTtcblxuICAgIC8vIFZlcmlmeSByb2xlcyBhZGRlZFxuICAgIHZhciByb2xlc0FkZGVkID0gUm9sZXMuZ2V0QWxsUm9sZXMoKS5mZXRjaCgpO1xuICAgIHJvbGVzID0gWydhRGV2ZWxvcGVyJywgJ0NLQ0MnLCBSb2xlcy5HTE9CQUxfR1JPVVAsIF0sXG4gICAgXy5lYWNoKHJvbGVzLCBmdW5jdGlvbihyb2xlKSB7XG4gICAgICAgIHZhciBmb3VuZCA9IF8uZmluZChyb2xlc0FkZGVkLCBmdW5jdGlvbiAoYWRkZWQpIHtcbiAgICAgICAgICAgIHJldHVybiBhZGRlZC5uYW1lID09PSByb2xlO1xuICAgICAgICB9KTtcbiAgICAgICAgaWYgKCFmb3VuZCkge1xuICAgICAgICAgICAgY29uc29sZS5sb2coJ0ZBSUxFRDosIHJvbGUgbm90IGFkZGVkOicsIHJvbGUpO1xuICAgICAgICAgICAgZmFpbHVyZXMgKz0gMTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIFxuICAgIC8vIFZlcmlmeSB1c2VycyBhcmUgYWRkZWQgdG8gY29ycmVjdCByb2xlc1xuICAgIC8vIEFzc3VtaW5nIHVzZXJzQWRkZWQgJiByb2xlc0FkZGVkIGFyZSBpbiB0aGUgc2FtZSBvcmRlciBhcyBhZGRlZFxuICAgIGlmICghUm9sZXMudXNlcklzSW5Sb2xlKHVzZXJzQWRkZWRbMF0sIHJvbGVzWzBdKSkge1xuICAgICAgICBjb25zb2xlLmxvZygnRkFJTEVEOiB1c2VyIG5vdCBpbiByb2xlOiAnLCB1c2Vyc0FkZGVkWzBdLnVzZXJuYW1lLCByb2xlc1swXSk7XG4gICAgICAgIGZhaWx1cmVzICs9IDE7XG4gICAgfVxuICAgIGlmICghUm9sZXMudXNlcklzSW5Sb2xlKHVzZXJzQWRkZWRbMF0sIHJvbGVzWzFdKSkge1xuICAgICAgICBjb25zb2xlLmxvZygnRkFJTEVEOiB1c2VyIG5vdCBpbiByb2xlOiAnLCB1c2Vyc0FkZGVkWzBdLnVzZXJuYW1lLCByb2xlc1sxXSk7XG4gICAgICAgIGZhaWx1cmVzICs9IDE7XG4gICAgfVxuICAgIGlmICghUm9sZXMudXNlcklzSW5Sb2xlKHVzZXJzQWRkZWRbMV0sIHJvbGVzWzFdKSkge1xuICAgICAgICBjb25zb2xlLmxvZygnRkFJTEVEOiB1c2VyIG5vdCBpbiByb2xlOiAnLCB1c2Vyc0FkZGVkWzFdLnVzZXJuYW1lLCByb2xlc1sxXSk7XG4gICAgICAgIGZhaWx1cmVzICs9IDE7XG4gICAgfVxuICAgIGlmICghUm9sZXMudXNlcklzSW5Sb2xlKHVzZXJzQWRkZWRbMl0sIHJvbGVzWzJdKSkge1xuICAgICAgICBjb25zb2xlLmxvZygnRkFJTEVEOiB1c2VyIG5vdCBpbiByb2xlOiAnLCB1c2Vyc0FkZGVkWzJdLnVzZXJuYW1lLCByb2xlc1syXSk7XG4gICAgICAgIGZhaWx1cmVzICs9IDE7XG4gICAgfVxuIFxuICAgIC8vIFZlcmlmeSB1c2VycyBoYXZlIHRoZSBjb3JyZWN0IG51bWJlciBvZiByb2xlc1xuICAgIHZhciB1c2VyUm9sZXMgPSBSb2xlcy5nZXRSb2xlc0ZvclVzZXIodXNlcnNBZGRlZFswXS5faWQpO1xuICAgIGlmICh1c2VyUm9sZXMubGVuZ3RoICE9PSAyKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKFwiRkFJTEVEOiB1c2VyJ3Mgcm9sZSBjb3VudCBzaG91bGQgYmUgMlwiLCB1c2Vyc0FkZGVkWzBdLnVzZXJuYW1lKTtcbiAgICAgICAgZmFpbHVyZXMgKz0gMTtcbiAgICB9XG4gICAgdXNlclJvbGVzID0gUm9sZXMuZ2V0Um9sZXNGb3JVc2VyKHVzZXJzQWRkZWRbMV0uX2lkKTtcbiAgICBpZiAodXNlclJvbGVzLmxlbmd0aCAhPT0gMSkge1xuICAgICAgICBjb25zb2xlLmxvZyhcIkZBSUxFRDogdXNlcidzIHJvbGUgY291bnQgc2hvdWxkIGJlIDFcIiwgdXNlcnNBZGRlZFsxXS51c2VybmFtZSk7XG4gICAgICAgIGZhaWx1cmVzICs9IDE7XG4gICAgfVxuICAgIHVzZXJSb2xlcyA9IFJvbGVzLmdldFJvbGVzRm9yVXNlcih1c2Vyc0FkZGVkWzJdLl9pZCk7XG4gICAgaWYgKHVzZXJSb2xlcy5sZW5ndGggIT09IDEpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCJGQUlMRUQ6IHVzZXIncyByb2xlIGNvdW50IHNob3VsZCBiZSAxXCIsIHVzZXJzQWRkZWRbMl0udXNlcm5hbWUpO1xuICAgICAgICBmYWlsdXJlcyArPSAxO1xuICAgIH1cbiAgICBcbiAgICBpZiAoZmFpbHVyZXMgPCAxKSBjb25zb2xlLmxvZygnQWxsIHVzZXIgdGVzdHMgd2VyZSBzdWNjZXNzZnVsIScpO1xufVxuXG5cbi8vcnVuVW5pdFRlc3RzKCkgLy8gdHVybiBvZmYgd2hlbiBub3QgdGVzdGluZztcblxuLy8gTW9yZSBFeGFtcGxlIGNhbGxzIC8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cbi8vIEluc2VydCBhIHVzZXIgaW50byB0aGUgdXNlcnMgZGIgdGFibGUgdmlhIHRoZSBsb2dpbiBVSVxuXG4vLyBncm91cElkIGlzIGVxdWl2YWxlbnQgdG8gX2lkIGluIHRoZSBkYi5cbi8vIHVzZXJJZCBpcyBlcXVpdmFsZW50IHRvIF9pZCBpbiB0aGUgZGIuXG5cbi8qXG5NZXRlb3IuY2FsbCgnZmluZFVzZXInLCAnQ1lobTduTUxxaVJQcFdZZFgnLCBmdW5jdGlvbiAoZXJyb3IsIHVzZXIpIHtcbiAgICBjb25zb2xlLmxvZygndXNlci5lbWFpbHNbMF0uYWRkcmVzcycsIHVzZXIuZW1haWxzWzBdLmFkZHJlc3MpO1xufSk7XG4qL1xuXG4vKlxuLy8gRmluZCBhbGwgdXNlcnMuXG5NZXRlb3IuY2FsbCgnZmluZEFsbFVzZXJzJywgZnVuY3Rpb24gKGVycm9yLCB1c2Vycykge1xuICAgIF8uZWFjaCh1c2VycywgZnVuY3Rpb24gKHVzZXIpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ3VzZXInLCB1c2VyLmVtYWlsc1swXS5hZGRyZXNzLCB1c2VyLnVzZXJuYW1lKTtcbiAgICB9KTtcbn0pO1xuKi9cbiJdfQ==
