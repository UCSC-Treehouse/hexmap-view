/* Imports for global scope */

MongoInternals = Package.mongo.MongoInternals;
Mongo = Package.mongo.Mongo;
Tracker = Package.tracker.Tracker;
Deps = Package.tracker.Deps;
ECMAScript = Package.ecmascript.ECMAScript;
check = Package.check.check;
Match = Package.check.Match;
Random = Package.random.Random;
ReactiveDict = Package['reactive-dict'].ReactiveDict;
ReactiveVar = Package['reactive-var'].ReactiveVar;
EJSON = Package.ejson.EJSON;
Roles = Package['alanning:roles'].Roles;
HTTP = Package.http.HTTP;
HTTPInternals = Package.http.HTTPInternals;
meteorInstall = Package.modules.meteorInstall;
_ = Package.underscore._;
Meteor = Package.meteor.Meteor;
global = Package.meteor.global;
meteorEnv = Package.meteor.meteorEnv;
WebApp = Package.webapp.WebApp;
WebAppInternals = Package.webapp.WebAppInternals;
main = Package.webapp.main;
DDP = Package['ddp-client'].DDP;
DDPServer = Package['ddp-server'].DDPServer;
LaunchScreen = Package['launch-screen'].LaunchScreen;
Blaze = Package.ui.Blaze;
UI = Package.ui.UI;
Handlebars = Package.ui.Handlebars;
Spacebars = Package.spacebars.Spacebars;
meteorBabelHelpers = Package['babel-runtime'].meteorBabelHelpers;
Promise = Package.promise.Promise;
Accounts = Package['accounts-base'].Accounts;
BrowserPolicy = Package['browser-policy-common'].BrowserPolicy;
Autoupdate = Package.autoupdate.Autoupdate;
HTML = Package.htmljs.HTML;

